using UnityEngine;
using UnityEngine.UI;
using GameplayMechanicsUMFOSS.Systems;

namespace GameplayMechanicsUMFOSS.Samples.CheckpointSystem
{
    /// <summary>
    /// Attach to an empty GameObject in your scene.
    /// Drag a UI Text (or TMP_Text) object into the HudText field.
    /// Displays live checkpoint state and the last event that fired.
    /// </summary>
    public class CheckpointHUD : MonoBehaviour
    {
        [Header("UI Reference")]
        [SerializeField] private Text hudText; // Use Unity's built-in Text; swap for TMP_Text if you use TextMeshPro

        [Header("Player Reference (auto-found if left empty)")]
        [SerializeField] private GameObject player;

        private string lastEvent = "None";
        private HealthSystem_UMFOSS health;

        // ─────────────────────────────────────────────────────────────────────────
        // Lifecycle
        // ─────────────────────────────────────────────────────────────────────────

        private void Awake()
        {
            if (player == null)
                player = GameObject.FindGameObjectWithTag("Player");

            if (player != null)
                health = player.GetComponent<HealthSystem_UMFOSS>();
        }

        private void OnEnable()
        {
            EventBus.Subscribe<OnCheckpointActivated>(OnActivated);
            EventBus.Subscribe<OnCheckpointDeactivated>(OnDeactivated);
            EventBus.Subscribe<OnRespawnStarted>(OnRespawnStarted);
            EventBus.Subscribe<OnRespawnComplete>(OnRespawnComplete);
            EventBus.Subscribe<OnAllCheckpointsCleared>(OnAllCleared);
        }

        private void OnDisable()
        {
            EventBus.Unsubscribe<OnCheckpointActivated>(OnActivated);
            EventBus.Unsubscribe<OnCheckpointDeactivated>(OnDeactivated);
            EventBus.Unsubscribe<OnRespawnStarted>(OnRespawnStarted);
            EventBus.Unsubscribe<OnRespawnComplete>(OnRespawnComplete);
            EventBus.Unsubscribe<OnAllCheckpointsCleared>(OnAllCleared);
        }

        private void Update()
        {
            if (hudText == null || CheckpointManager_UMFOSS.Instance == null) return;

            var active      = CheckpointManager_UMFOSS.Instance.GetActiveCheckpoint();
            var respawnPos  = CheckpointManager_UMFOSS.Instance.GetRespawnPosition();
            var healthVal   = health != null ? health.GetMaxHealth().ToString("F0") : "N/A";

            hudText.text =
                $"Active Checkpoint : {(active != null ? active.CheckpointID : "None")}\n" +
                $"Respawn Position  : {respawnPos}\n" +
                $"Player Health     : {healthVal}\n" +
                $"Last Event        : {lastEvent}\n\n" +
                $"H = Die | R = Respawn | Backspace = Reset";
        }

        // ─────────────────────────────────────────────────────────────────────────
        // Event Callbacks
        // ─────────────────────────────────────────────────────────────────────────

        private void OnActivated(OnCheckpointActivated e)
            => lastEvent = $"CheckpointActivated → {e.checkpoint.CheckpointID}";

        private void OnDeactivated(OnCheckpointDeactivated e)
            => lastEvent = $"CheckpointDeactivated → {e.checkpoint.CheckpointID}";

        private void OnRespawnStarted(OnRespawnStarted e)
            => lastEvent = $"RespawnStarted (died at {e.deathPosition})";

        private void OnRespawnComplete(OnRespawnComplete e)
            => lastEvent = $"RespawnComplete → {e.respawnPosition}";

        private void OnAllCleared(OnAllCheckpointsCleared e)
            => lastEvent = "AllCheckpointsCleared";
    }
}
