using UnityEngine;
using GameplayMechanicsUMFOSS.Systems;

namespace GameplayMechanicsUMFOSS.Samples.CheckpointSystem
{
    /// <summary>
    /// A very basic 2D player controller to let you walk, jump, and interact in the demo scene.
    /// - WASD / Arrows to move left and right
    /// - Space to jump
    /// - E to interact with things (like Checkpoint B)
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class CheckpointDemoPlayer : MonoBehaviour
    {
        public float moveSpeed = 5f;
        public float jumpForce = 8f;
        
        private Rigidbody2D rb;
        private bool isGrounded;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
        }

        private void Update()
        {
            // 2D Movement
            float moveX = Input.GetAxis("Horizontal");
            rb.velocity = new Vector2(moveX * moveSpeed, rb.velocity.y);

            // Jump
            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
                isGrounded = false;
            }

            // Interact (Press E)
            if (Input.GetKeyDown(KeyCode.E))
            {
                Collider2D[] hitColliders = Physics2D.OverlapCircleAll(transform.position, 2f);
                foreach (var hitCollider in hitColliders)
                {
                    var interactable = hitCollider.GetComponentInParent<IInteractable_UMFOSS>();
                    if (interactable != null && interactable.CanInteract(gameObject))
                    {
                        interactable.Interact(gameObject);
                        Debug.Log("[CheckpointDemoPlayer] Interacted with: " + hitCollider.name);
                        break;
                    }
                }
            }

            // Failsafe: If we fall below Y = -5 (the void), trigger death
            if (transform.position.y < -5f)
            {
                Debug.Log("[CheckpointDemoPlayer] Player fell into the void!");
                EventBus.Publish(new DeathEvent { source = gameObject });
            }
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            // Basic ground detection for 2D platforming
            if (collision.contacts[0].normal.y > 0.5f)
            {
                isGrounded = true;
            }
        }
    }
}
