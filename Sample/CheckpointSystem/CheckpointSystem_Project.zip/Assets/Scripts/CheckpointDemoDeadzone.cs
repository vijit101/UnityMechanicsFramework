using UnityEngine;
using GameplayMechanicsUMFOSS.Systems;

namespace GameplayMechanicsUMFOSS.Samples.CheckpointSystem
{
    /// <summary>
    /// A simple trigger that acts as a bottomless pit or spikes.
    /// Kills the player instantly and triggers the respawn sequence.
    /// </summary>
    public class CheckpointDemoDeadzone : MonoBehaviour
    {
        private void OnTriggerEnter(Collider other) => HandleDeath(other.gameObject);
        private void OnTriggerEnter2D(Collider2D other) => HandleDeath(other.gameObject);
        private void OnCollisionEnter(Collision other) => HandleDeath(other.gameObject);
        private void OnCollisionEnter2D(Collision2D other) => HandleDeath(other.gameObject);

        private void HandleDeath(GameObject go)
        {
            if (go.CompareTag("Player"))
            {
                Debug.Log("[Deadzone] Death triggered for: " + go.name);
                EventBus.Publish(new DeathEvent { source = go });
            }
        }
    }
}
