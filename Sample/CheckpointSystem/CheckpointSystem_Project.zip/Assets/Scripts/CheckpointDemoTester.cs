using UnityEngine;
using GameplayMechanicsUMFOSS.Systems;

namespace GameplayMechanicsUMFOSS.Samples.CheckpointSystem
{
    /// <summary>
    /// Attach to the Player GameObject.
    /// Keyboard shortcuts for testing the Checkpoint & Respawn system in the demo scene.
    ///   H          — instantly kills the player (calls TakeDamage(9999))
    ///   R          — manually triggers a respawn without dying
    ///   Backspace  — resets all checkpoints, active returns to Starting Checkpoint
    /// </summary>
    public class CheckpointDemoTester : MonoBehaviour
    {
        private HealthSystem_UMFOSS health;

        private void Awake()
        {
            health = GetComponent<HealthSystem_UMFOSS>();

            if (health == null)
                Debug.LogWarning("[CheckpointDemoTester] No HealthSystem_UMFOSS found on this GameObject.");
        }

        private void Update()
        {
            // H — kill player, triggers OnDeath → CheckpointManager listens → RespawnSequence
            if (Input.GetKeyDown(KeyCode.H))
            {
                Debug.Log("[DemoTester] H pressed — triggering player death.");
                health?.TakeDamage(9999f);
            }

            // R — manual respawn (same flow as death, bypasses HealthSystem)
            if (Input.GetKeyDown(KeyCode.R))
            {
                Debug.Log("[DemoTester] R pressed — manually triggering respawn.");
                CheckpointManager_UMFOSS.Instance?.TriggerRespawn();
            }

            // Backspace — reset all checkpoints back to Starting Checkpoint
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                Debug.Log("[DemoTester] Backspace pressed — resetting all checkpoints.");
                CheckpointManager_UMFOSS.Instance?.ResetAllCheckpoints();
            }
        }
    }
}
