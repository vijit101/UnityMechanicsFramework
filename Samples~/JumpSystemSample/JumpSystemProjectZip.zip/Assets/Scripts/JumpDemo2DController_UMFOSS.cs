using UnityEngine;
using UnityEngine.InputSystem;
using GameplayMechanicsUMFOSS.Movement;

namespace GameplayMechanicsUMFOSS.Samples.Jump
{
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(ModularJumpSystem_UMFOSS))]
    public class JumpDemo2DController_UMFOSS : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] private float moveSpeed = 7f;

        private Rigidbody2D rb;
        private ModularJumpSystem_UMFOSS jumpSystem;
        private bool jumpPressedLastFrame;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            jumpSystem = GetComponent<ModularJumpSystem_UMFOSS>();

            jumpSystem.OnJumpStart += () => Debug.Log("Jump started!");
            jumpSystem.OnJumpEnd += () => Debug.Log("Landed!");
        }

        private void Update()
        {
            Keyboard kb = Keyboard.current;
            if (kb == null) return;

            // Horizontal movement
            float horizontal = 0f;
            if (kb.aKey.isPressed || kb.leftArrowKey.isPressed) horizontal = -1f;
            if (kb.dKey.isPressed || kb.rightArrowKey.isPressed) horizontal = 1f;

            float speed = moveSpeed * jumpSystem.AirControlMultiplier;
            rb.linearVelocity = new Vector2(horizontal * speed, rb.linearVelocity.y);

            // Jump input
            bool jumpPressed = kb.spaceKey.isPressed;

            if (jumpPressed && !jumpPressedLastFrame)
            {
                jumpSystem.OnJumpPressed();
            }
            if (!jumpPressed && jumpPressedLastFrame)
            {
                jumpSystem.OnJumpReleased();
            }

            jumpPressedLastFrame = jumpPressed;
        }
    }
}
