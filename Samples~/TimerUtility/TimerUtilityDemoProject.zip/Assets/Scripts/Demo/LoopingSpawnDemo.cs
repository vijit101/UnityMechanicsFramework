using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GameplayMechanicsUMFOSS.Utils;

namespace GameplayMechanicsUMFOSS.Samples.TimerUtility
{
    /// <summary>
    /// Demo 3: Looping Spawn Timer — fully self-contained, creates its own UI.
    /// Spawns a coloured square on the canvas every 3 seconds, 5 times.
    /// This simulates how a game spawns enemies or items at regular intervals.
    /// Just attach this script to any GameObject. Press Play. No wiring needed.
    /// </summary>
    public class LoopingSpawnDemo : MonoBehaviour
    {
        private TMP_Text            spawnCountLabel;
        private RectTransform       spawnArea;
        private TimerUtility_UMFOSS spawnTimer;

        private int spawnedCount      = 0;
        private const int   MAX_SPAWNS      = 5;
        private const float SPAWN_INTERVAL  = 3f;

        // Colours for each spawned square (like different enemy types)
        private readonly Color[] colors = new Color[]
        {
            new Color(1f,   0.3f, 0.3f), // red
            new Color(1f,   0.7f, 0.2f), // orange
            new Color(0.3f, 1f,   0.3f), // green
            new Color(0.3f, 0.7f, 1f),   // blue
            new Color(0.8f, 0.3f, 1f),   // purple
        };

        private void Awake()
        {
            BuildUI();
        }

        private void Start()
        {
            // Use the static factory — caller never manages a GameObject!
            spawnTimer = TimerUtility_UMFOSS.CreateLooping(
                interval: SPAWN_INTERVAL,
                onTick:   SpawnSquare
            );
        }

        private void SpawnSquare()
        {
            if (spawnedCount >= MAX_SPAWNS)
            {
                spawnTimer.Stop();
                return;
            }

            // Create a coloured square inside the spawn area on the canvas
            var squareGO   = new GameObject($"Enemy_{spawnedCount + 1}");
            squareGO.transform.SetParent(spawnArea, false);

            var img        = squareGO.AddComponent<Image>();
            img.color      = colors[spawnedCount % colors.Length];

            var rect       = squareGO.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(60f, 60f);
            // Place squares in a row, left to right
            rect.anchoredPosition = new Vector2(spawnedCount * 75f - 150f, 0f);

            spawnedCount++;
            UpdateLabel();
        }

        private void UpdateLabel()
        {
            if (spawnCountLabel == null) return;

            spawnCountLabel.text = spawnedCount >= MAX_SPAWNS
                ? $"Spawned: {spawnedCount}/{MAX_SPAWNS}  — All done!"
                : $"Spawned: {spawnedCount}/{MAX_SPAWNS}  (next in {SPAWN_INTERVAL}s)";
        }

        private void BuildUI()
        {
            Canvas canvas = FindAnyObjectByType<Canvas>();
            if (canvas == null)
            {
                var cgo = new GameObject("Canvas");
                canvas = cgo.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                cgo.AddComponent<CanvasScaler>();
                cgo.AddComponent<GraphicRaycaster>();
            }

            // Title
            CreateLabel(canvas.transform, "Demo3Title",
                "DEMO 3 — Spawn Timer (enemy every 3s)", new Vector2(700f, 450f), 18);

            // Counter label
            spawnCountLabel = CreateLabel(canvas.transform, "SpawnCountLabel",
                $"Spawned: 0/{MAX_SPAWNS}  (first in {SPAWN_INTERVAL}s)",
                new Vector2(700f, 395f), 18);
            spawnCountLabel.color = new Color(1f, 0.8f, 0.2f);

            // Spawn area — a container where squares will appear
            var areaGO    = new GameObject("SpawnArea");
            areaGO.transform.SetParent(canvas.transform, false);
            var areaBg    = areaGO.AddComponent<Image>();
            areaBg.color  = new Color(0.15f, 0.15f, 0.25f, 0.8f);
            spawnArea     = areaGO.GetComponent<RectTransform>();
            spawnArea.anchoredPosition = new Vector2(700f, 310f);
            spawnArea.sizeDelta        = new Vector2(400f, 80f);

            // Label above spawn area
            CreateLabel(canvas.transform, "SpawnAreaLabel",
                "↓ Enemies appear here ↓", new Vector2(700f, 360f), 14);
        }

        private TMP_Text CreateLabel(Transform parent, string name, string text,
                                     Vector2 position, float fontSize)
        {
            var go        = new GameObject(name);
            go.transform.SetParent(parent, false);
            var tmp       = go.AddComponent<TextMeshProUGUI>();
            tmp.text      = text;
            tmp.fontSize  = fontSize;
            tmp.color     = Color.white;
            tmp.alignment = TextAlignmentOptions.Center;
            var rect      = go.GetComponent<RectTransform>();
            rect.anchoredPosition = position;
            rect.sizeDelta        = new Vector2(420f, 50f);
            return tmp;
        }
    }
}
