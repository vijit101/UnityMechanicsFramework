using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GameplayMechanicsUMFOSS.Utils;

namespace GameplayMechanicsUMFOSS.Samples.TimerUtility
{
    /// <summary>
    /// Demo 1: Cooldown Timer — fully self-contained, creates its own UI.
    /// Just attach this script to any GameObject. Press Play. No wiring needed.
    /// </summary>
    public class CooldownTimerDemo : MonoBehaviour
    {
        // ── Runtime-created UI references ──────────────────
        private Button              abilityButton;
        private TMP_Text            buttonText;
        private TMP_Text            cooldownLabel;
        private TimerUtility_UMFOSS cooldownTimer;

        // ── Constants ───────────────────────────────────────
        private const float COOLDOWN_DURATION  = 5f;
        private const float TICK_INTERVAL      = 0.5f;

        private void Awake()
        {
            BuildUI();

            // Add timer component to this GameObject
            cooldownTimer              = gameObject.AddComponent<TimerUtility_UMFOSS>();
            cooldownTimer.SetDuration(COOLDOWN_DURATION, false);

            // Enable ticks every 0.5s so label updates feel smooth
            // (We control tick via SetDuration; ticks are wired below)
        }

        private void Start()
        {
            cooldownTimer.OnTimerStart    += OnCooldownStart;
            cooldownTimer.OnTimerComplete += OnCooldownEnd;
            abilityButton.onClick.AddListener(OnAbilityPressed);
            cooldownLabel.text = "Ability Ready!";
        }

        private void Update()
        {
            // Smooth live update of the label while running
            if (cooldownTimer.IsRunning())
                cooldownLabel.text = $"Cooldown: {cooldownTimer.GetTimeRemaining():F1}s";
        }

        private void OnDestroy()
        {
            if (cooldownTimer != null)
            {
                cooldownTimer.OnTimerStart    -= OnCooldownStart;
                cooldownTimer.OnTimerComplete -= OnCooldownEnd;
            }
        }

        // ── Timer callbacks ─────────────────────────────────

        private void OnAbilityPressed()
        {
            if (!cooldownTimer.IsRunning())
                cooldownTimer.Start();
        }

        private void OnCooldownStart()
        {
            abilityButton.interactable = false;
            buttonText.text            = "...";
        }

        private void OnCooldownEnd()
        {
            abilityButton.interactable = true;
            buttonText.text            = "USE ABILITY";
            cooldownLabel.text         = "Ability Ready!";
        }

        // ── UI Builder ──────────────────────────────────────

        private void BuildUI()
        {
            Canvas canvas = FindAnyObjectByType<Canvas>();
            if (canvas == null)
            {
                var canvasGO = new GameObject("Canvas");
                canvas = canvasGO.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvasGO.AddComponent<CanvasScaler>();
                canvasGO.AddComponent<GraphicRaycaster>();
                new GameObject("EventSystem").AddComponent<UnityEngine.EventSystems.EventSystem>()
                    .gameObject.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
            }

            // ── Title ──
            CreateLabel(canvas.transform, "Demo1Title", "DEMO 1 — Cooldown Timer",
                new Vector2(-700f, 450f), 22);

            // ── Ability Button ──
            var btnGO = new GameObject("AbilityButton_Demo1");
            btnGO.transform.SetParent(canvas.transform, false);
            var btnImg = btnGO.AddComponent<Image>();
            btnImg.color = new Color(0.2f, 0.6f, 1f);
            abilityButton = btnGO.AddComponent<Button>();

            var btnRect = btnGO.GetComponent<RectTransform>();
            btnRect.anchoredPosition = new Vector2(-700f, 380f);
            btnRect.sizeDelta        = new Vector2(240f, 65f);

            // Button label
            var btnLabelGO = new GameObject("BtnText");
            btnLabelGO.transform.SetParent(btnGO.transform, false);
            buttonText           = btnLabelGO.AddComponent<TextMeshProUGUI>();
            buttonText.text      = "USE ABILITY";
            buttonText.fontSize  = 18;
            buttonText.alignment = TextAlignmentOptions.Center;
            buttonText.color     = Color.white;
            var btnLabelRect = btnLabelGO.GetComponent<RectTransform>();
            btnLabelRect.anchorMin = Vector2.zero;
            btnLabelRect.anchorMax = Vector2.one;
            btnLabelRect.sizeDelta = Vector2.zero;

            // ── Status label ──
            cooldownLabel = CreateLabel(canvas.transform, "CooldownLabel_Demo1",
                "Ability Ready!", new Vector2(-700f, 300f), 20);
        }

        private TMP_Text CreateLabel(Transform parent, string name, string text,
                                     Vector2 position, float fontSize)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var tmp           = go.AddComponent<TextMeshProUGUI>();
            tmp.text          = text;
            tmp.fontSize      = fontSize;
            tmp.color         = Color.white;
            tmp.alignment     = TextAlignmentOptions.Center;
            var rect          = go.GetComponent<RectTransform>();
            rect.anchoredPosition = position;
            rect.sizeDelta    = new Vector2(300f, 50f);
            return tmp;
        }
    }
}
