using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GameplayMechanicsUMFOSS.Utils;

namespace GameplayMechanicsUMFOSS.Samples.TimerUtility
{
    /// <summary>
    /// Demo 2: Countdown Display — fully self-contained, creates its own UI.
    /// Just attach this script to any GameObject. Press Play. No wiring needed.
    /// </summary>
    public class CountdownDisplayDemo : MonoBehaviour
    {
        private TMP_Text             countdownText;
        private TMP_Text             statusText;
        private TimerUtility_UMFOSS  roundTimer;

        private const float ROUND_DURATION   = 30f;
        private const float TICK_INTERVAL    = 1f;

        private void Awake()
        {
            BuildUI();
            roundTimer = gameObject.AddComponent<TimerUtility_UMFOSS>();
            roundTimer.SetDuration(ROUND_DURATION, false);
        }

        private void Start()
        {
            roundTimer.OnTimerStart    += () => statusText.text = "Round in progress...";
            roundTimer.OnTimerComplete += OnRoundEnd;
            roundTimer.Start();
        }

        private void Update()
        {
            if (roundTimer.IsRunning())
                countdownText.text = $"{roundTimer.GetTimeRemaining():F1}s";
        }

        private void OnRoundEnd()
        {
            countdownText.text = "0s";
            statusText.text    = "ROUND OVER!";
        }

        private void BuildUI()
        {
            Canvas canvas = FindAnyObjectByType<Canvas>();
            if (canvas == null)
            {
                var cgo = new GameObject("Canvas");
                canvas = cgo.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                cgo.AddComponent<CanvasScaler>();
                cgo.AddComponent<GraphicRaycaster>();
            }

            CreateLabel(canvas.transform, "Demo2Title", "DEMO 2 — Round Timer",
                new Vector2(0f, 450f), 22);
            countdownText = CreateLabel(canvas.transform, "CountdownText",
                $"{ROUND_DURATION}s", new Vector2(0f, 360f), 56);
            countdownText.color = new Color(0.3f, 1f, 0.5f);
            statusText = CreateLabel(canvas.transform, "StatusText",
                "Press Play to start", new Vector2(0f, 270f), 20);
        }

        private TMP_Text CreateLabel(Transform parent, string name, string text,
                                     Vector2 position, float fontSize)
        {
            var go            = new GameObject(name);
            go.transform.SetParent(parent, false);
            var tmp           = go.AddComponent<TextMeshProUGUI>();
            tmp.text          = text;
            tmp.fontSize      = fontSize;
            tmp.color         = Color.white;
            tmp.alignment     = TextAlignmentOptions.Center;
            var rect          = go.GetComponent<RectTransform>();
            rect.anchoredPosition = position;
            rect.sizeDelta    = new Vector2(300f, 60f);
            return tmp;
        }
    }
}
