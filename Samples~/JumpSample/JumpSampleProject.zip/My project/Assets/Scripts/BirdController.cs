using UnityEngine;
using GameplayMechanicsUMFOSS.Movement;
using GameplayMechanicsUMFOSS.Physics;

public class BirdController : MonoBehaviour
{
    [Header("Rotation")]
    [SerializeField] private float maxUpAngle = 30f;
    [SerializeField] private float maxDownAngle = -70f;
    [SerializeField] private float rotationSpeed = 8f;

    [Header("Boundaries")]
    [SerializeField] private float maxHeight = 4.5f;

    [Header("References")]
    [SerializeField] private ModularJumpSystem jumpSystem;

    private IPhysicsAdapter physicsAdapter;
    private bool hasStarted;
    private bool isDead;

    private void Start()
    {
        physicsAdapter = GetComponent<Physics2DAdapter>();

        if (jumpSystem != null)
        {
            jumpSystem.OnJumpStart += OnFlap;
        }

        // Freeze the bird until game starts
        var rb = GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.simulated = false;
        }
    }

    private void OnFlap()
    {
        if (isDead) return;

        if (!hasStarted)
        {
            hasStarted = true;

            var rb = GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.simulated = true;
            }

            if (FlappyGameManager.Instance != null)
            {
                FlappyGameManager.Instance.StartGame();
            }
        }
    }

    private void Update()
    {
        if (isDead) return;
        if (FlappyGameManager.Instance == null) return;
        if (FlappyGameManager.Instance.CurrentState == GameState.GameOver) return;

        UpdateRotation();
        ClampHeight();
    }

    private void UpdateRotation()
    {
        if (physicsAdapter == null) return;

        float velocityY = physicsAdapter.Velocity.y;
        float targetAngle = Mathf.Lerp(maxDownAngle, maxUpAngle, Mathf.InverseLerp(-10f, 10f, velocityY));
        float currentAngle = transform.eulerAngles.z;
        if (currentAngle > 180f) currentAngle -= 360f;

        float newAngle = Mathf.Lerp(currentAngle, targetAngle, Time.deltaTime * rotationSpeed);
        transform.rotation = Quaternion.Euler(0f, 0f, newAngle);
    }

    private void ClampHeight()
    {
        if (transform.position.y > maxHeight)
        {
            transform.position = new Vector3(transform.position.x, maxHeight, transform.position.z);
            if (physicsAdapter != null && physicsAdapter.Velocity.y > 0f)
            {
                physicsAdapter.SetVerticalVelocity(0f);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isDead) return;
        if (FlappyGameManager.Instance == null) return;
        if (FlappyGameManager.Instance.CurrentState != GameState.Playing) return;

        isDead = true;

        // Disable the jump system so Space doesn't flap anymore
        if (jumpSystem != null)
        {
            jumpSystem.enabled = false;
        }

        FlappyGameManager.Instance.TriggerGameOver();
    }

    private void OnDestroy()
    {
        if (jumpSystem != null)
        {
            jumpSystem.OnJumpStart -= OnFlap;
        }
    }
}
