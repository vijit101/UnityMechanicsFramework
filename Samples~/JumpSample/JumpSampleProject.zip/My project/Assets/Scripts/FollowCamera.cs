using UnityEngine;

/// <summary>
/// Third-person camera with mouse orbit. Right-click + drag to rotate camera.
/// Scroll to zoom. Camera auto-follows player.
/// </summary>
public class FollowCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private float distance = 8f;
    [SerializeField] private float height = 4f;
    [SerializeField] private float mouseSensitivity = 3f;
    [SerializeField] private float smoothSpeed = 10f;
    [SerializeField] private float minVerticalAngle = -10f;
    [SerializeField] private float maxVerticalAngle = 60f;
    [SerializeField] private float minDistance = 3f;
    [SerializeField] private float maxDistance = 15f;

    private float yaw;
    private float pitch = 15f;

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        if (target != null)
        {
            Vector3 dir = transform.position - target.position;
            yaw = Mathf.Atan2(dir.x, dir.z) * Mathf.Rad2Deg;
        }
    }

    private void Update()
    {
        // Escape to unlock cursor
        if (UnityEngine.InputSystem.Keyboard.current != null &&
            UnityEngine.InputSystem.Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            Cursor.lockState = Cursor.lockState == CursorLockMode.Locked
                ? CursorLockMode.None
                : CursorLockMode.Locked;
            Cursor.visible = Cursor.lockState != CursorLockMode.Locked;
        }

        // Mouse rotation (always active when cursor is locked)
        if (Cursor.lockState == CursorLockMode.Locked)
        {
            yaw += UnityEngine.InputSystem.Mouse.current.delta.x.ReadValue() * mouseSensitivity * 0.1f;
            pitch -= UnityEngine.InputSystem.Mouse.current.delta.y.ReadValue() * mouseSensitivity * 0.1f;
            pitch = Mathf.Clamp(pitch, minVerticalAngle, maxVerticalAngle);
        }

        // Scroll to zoom
        float scroll = UnityEngine.InputSystem.Mouse.current.scroll.y.ReadValue();
        if (Mathf.Abs(scroll) > 0.01f)
        {
            distance -= scroll * 0.002f;
            distance = Mathf.Clamp(distance, minDistance, maxDistance);
        }
    }

    private void LateUpdate()
    {
        if (target == null) return;

        // Calculate camera position from orbit angles
        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 offset = rotation * new Vector3(0f, 0f, -distance);
        offset.y += height;

        Vector3 desiredPos = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desiredPos, Time.deltaTime * smoothSpeed);

        // Always look at player
        Vector3 lookTarget = target.position + Vector3.up * 1.2f;
        transform.LookAt(lookTarget);
    }
}
