using UnityEngine;
using TMPro;

public class CoinUIUpdater : MonoBehaviour
{
    private TextMeshProUGUI tmp;

    private void Start()
    {
        tmp = GetComponent<TextMeshProUGUI>();
        Collectible.OnCollected += OnCoinCollected;
    }

    private void OnCoinCollected(int total)
    {
        if (tmp != null)
            tmp.text = $"<color=#FFD700>\u25CF</color>  {total}";
    }

    private void OnDestroy()
    {
        Collectible.OnCollected -= OnCoinCollected;
    }
}
