using UnityEngine;
using UnityEngine.InputSystem;
using GameplayMechanicsUMFOSS.Movement;
using GameplayMechanicsUMFOSS.Physics;

public class PlatformerSceneSetup : MonoBehaviour
{
    [Header("Input")]
    [SerializeField] private InputActionReference jumpAction;

    private const int GROUND_LAYER = 7;
    private Material urpLit;

    private void Awake()
    {
        urpLit = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (urpLit.shader.name == "Hidden/InternalErrorShader")
            urpLit = new Material(Shader.Find("Standard"));

        CreateLighting();
        CreateTerrain();
        CreateLevel();
        var player = CreatePlayer();
        SetupCamera(player.transform);
        CreateHUD();
        Destroy(gameObject);
    }

    // ══════════ LIGHTING ══════════

    private void CreateLighting()
    {
        foreach (var l in FindObjectsByType<Light>(FindObjectsInactive.Exclude, FindObjectsSortMode.None))
            Destroy(l.gameObject);

        var sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.color = new Color(1f, 0.95f, 0.85f);
        sun.intensity = 2f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = 0.55f;
        sun.transform.rotation = Quaternion.Euler(40f, 45f, 0f);

        var fill = new GameObject("Fill").AddComponent<Light>();
        fill.type = LightType.Directional;
        fill.color = new Color(0.55f, 0.7f, 1f);
        fill.intensity = 0.6f;
        fill.shadows = LightShadows.None;
        fill.transform.rotation = Quaternion.Euler(60f, -130f, 0f);
    }

    // ══════════ TERRAIN ══════════

    private void CreateTerrain()
    {
        // Ground
        Box("Ground", V(50, -0.25f, 0), V(140, 0.5f, 50), C(0.3f, 0.62f, 0.18f), GROUND_LAYER);

        // Water below
        Box("Water", V(50, -4, 0), V(250, 0.1f, 250), C(0.15f, 0.45f, 0.82f), col: false);

        // Dirt path
        Box("Path", V(50, 0.02f, 0), V(125, 0.04f, 4.5f), C(0.58f, 0.48f, 0.32f), col: false);

        // Trees (with collidable trunks)
        float[] tx = { -5, 3, 10, 18, 28, 40, 52, 62, 72, 80, 92, 100, 110 };
        float[] tz = { 7, -8, 9, -7, 8, -9, 7, -8, 9, -7, 8, -9, 7 };
        for (int i = 0; i < tx.Length; i++)
            CreateTree(V(tx[i], 0, tz[i]));

        // Rocks (collidable)
        CreateRock(V(5, 0.4f, -5), 1.2f);
        CreateRock(V(25, 0.4f, 6), 0.9f);
        CreateRock(V(45, 0.4f, -6), 1.5f);
        CreateRock(V(70, 0.4f, 7), 1.1f);
        CreateRock(V(95, 0.4f, -5), 1.3f);
    }

    private void CreateTree(Vector3 pos)
    {
        var tree = new GameObject("Tree");
        tree.transform.position = pos;
        float s = 0.8f + Random.Range(0, 0.5f);

        // Trunk — COLLIDABLE
        var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.name = "Trunk";
        trunk.transform.SetParent(tree.transform);
        trunk.transform.localPosition = V(0, 1.5f * s, 0);
        trunk.transform.localScale = V(0.5f * s, 1.5f * s, 0.5f * s);
        trunk.layer = GROUND_LAYER;
        SetColor(trunk, C(0.48f, 0.32f, 0.16f));

        // Leaves — 3 layered spheres
        float g = 0.4f + Random.Range(0, 0.12f);
        MakeSphere("L1", tree.transform, V(0, 2.8f * s, 0), V(2.5f * s, 2f * s, 2.5f * s), C(0.18f, g, 0.1f));
        MakeSphere("L2", tree.transform, V(0, 3.7f * s, 0), V(2f * s, 1.5f * s, 2f * s), C(0.22f, g + 0.06f, 0.12f));
        MakeSphere("L3", tree.transform, V(0, 4.3f * s, 0), V(1.3f * s, 1f * s, 1.3f * s), C(0.28f, g + 0.12f, 0.15f));
    }

    private void CreateRock(Vector3 pos, float scale)
    {
        // Main rock — COLLIDABLE
        var rock = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        rock.name = "Rock";
        rock.transform.position = pos;
        rock.transform.localScale = V(1.4f * scale, 0.8f * scale, 1.2f * scale);
        rock.layer = GROUND_LAYER;
        SetColor(rock, C(0.52f, 0.5f, 0.48f));

        // Small rock
        Sphere("SmRock", pos + V(0.8f * scale, -0.1f, 0.3f), V(0.5f * scale, 0.35f * scale, 0.45f * scale), C(0.58f, 0.55f, 0.52f));
    }

    // ══════════ LEVEL ══════════

    private void CreateLevel()
    {
        // Section 1: Warm-up
        Plat(5, 0.8f, 0, 4, 3.5f, C(0.8f, 0.55f, 0.25f)); Coin(5, 2.3f, 0);
        Plat(10, 1.5f, 2, 3.5f, 3, C(0.82f, 0.58f, 0.28f)); Coin(10, 3, 2);
        Plat(15, 2.2f, -1, 3.5f, 3, C(0.85f, 0.6f, 0.3f)); Coin(15, 3.7f, -1);

        // Section 2: Zigzag
        Plat(20, 3, -3, 3, 2.8f, C(0.45f, 0.3f, 0.68f)); Coin(20, 4.5f, -3);
        Plat(25, 4, 2, 3, 2.8f, C(0.5f, 0.35f, 0.72f)); Coin(25, 5.5f, 2);
        Plat(30, 5, -2, 3, 2.8f, C(0.55f, 0.38f, 0.76f));
        Plat(35, 6, 1, 3, 2.8f, C(0.6f, 0.42f, 0.8f)); Coin(32, 6.5f, 0);

        // Section 3: Rest + bridge
        Plat(40, 6.5f, 0, 6, 6, C(0.3f, 0.65f, 0.4f));
        Coin(40, 8, 2); Coin(40, 8, -2); Coin(40, 8, 0);
        Plat(46, 6.5f, 0, 1.5f, 1.5f, C(0.65f, 0.55f, 0.3f));
        Plat(50, 6.5f, 0, 1.5f, 1.5f, C(0.68f, 0.57f, 0.32f));
        Plat(54, 6.5f, 0, 1.5f, 1.5f, C(0.7f, 0.6f, 0.33f)); Coin(50, 8, 0);

        // Section 4: Tower
        Plat(58, 7.5f, 0, 3.5f, 3.5f, C(0.2f, 0.5f, 0.8f));
        Plat(58, 9.5f, 3, 2.5f, 2.5f, C(0.25f, 0.55f, 0.85f)); Coin(58, 11, 3);
        Plat(58, 11.5f, -2, 2.5f, 2.5f, C(0.3f, 0.6f, 0.9f));
        Plat(58, 13.5f, 1, 2.5f, 2.5f, C(0.35f, 0.65f, 0.95f)); Coin(58, 15, 1);

        // Section 5: Descent
        Plat(63, 12, 0, 3, 3, C(0.82f, 0.3f, 0.22f)); Coin(63, 13.5f, 0);
        Plat(68, 10, 2, 2.8f, 2.8f, C(0.78f, 0.28f, 0.2f));
        Plat(73, 8, -1, 2.8f, 2.8f, C(0.74f, 0.25f, 0.18f));
        Plat(78, 6, 1, 3, 3, C(0.7f, 0.22f, 0.16f)); Coin(75, 9.5f, 0);

        // Section 6: Long gaps
        Plat(84, 5.5f, 0, 2.2f, 2.2f, C(0.9f, 0.55f, 0.12f)); Coin(84, 7, 0);
        Plat(91, 6.5f, 0, 2.2f, 2.2f, C(0.92f, 0.58f, 0.15f)); Coin(87, 7.5f, 0);
        Plat(98, 7.5f, 0, 2.2f, 2.2f, C(0.95f, 0.6f, 0.18f)); Coin(94, 8.5f, 0);

        // Section 7: Final winding
        Plat(104, 7, 3, 3, 3, C(0.38f, 0.7f, 0.52f));
        Plat(110, 6, -3, 3, 3, C(0.42f, 0.72f, 0.55f)); Coin(107, 8, 0);
        Plat(116, 5, 2, 3, 3, C(0.45f, 0.75f, 0.58f)); Coin(113, 7, 0);

        // Victory
        Plat(122, 4.5f, 0, 7, 7, C(1f, 0.85f, 0.1f));
        // Trophy
        Cyl("Base", V(122, 5.5f, 0), V(1.2f, 0.4f, 1.2f), C(0.85f, 0.7f, 0.1f));
        Sphere("Cup", V(122, 7, 0), V(1.5f, 1.5f, 1.5f), C(1f, 0.88f, 0.2f));
        Sphere("Star", V(122, 7, 0), V(0.6f, 0.6f, 0.6f), C(1f, 1f, 0.7f));
        for (int i = 0; i < 6; i++)
        {
            float a = i * 60f * Mathf.Deg2Rad;
            Coin(122 + Mathf.Cos(a) * 2.5f, 6.5f, Mathf.Sin(a) * 2.5f);
        }
    }

    private void Plat(float x, float y, float z, float w, float d, Color c)
    {
        float h = 0.6f;
        var p = Box("Platform", V(x, y, z), V(w, h, d), c, GROUND_LAYER);
        // Top face highlight
        var top = Box("Top", V(0, 0.45f, 0), V(0.93f, 0.08f, 0.93f), c + C(0.1f, 0.1f, 0.1f), col: false);
        top.transform.SetParent(p.transform, false);
        // Dark bottom edge
        var bot = Box("Edge", V(0, -0.35f, 0), V(1.01f, 0.3f, 1.01f), c * 0.7f, col: false);
        bot.transform.SetParent(p.transform, false);
    }

    private void Coin(float x, float y, float z)
    {
        // Upright coin that spins around its face
        var coin = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        coin.name = "Coin";
        coin.transform.position = V(x, y, z);
        coin.transform.localScale = V(0.6f, 0.06f, 0.6f);
        // No initial rotation — stays upright, Collectible spins it
        Destroy(coin.GetComponent<Collider>());
        var sc = coin.AddComponent<SphereCollider>();
        sc.isTrigger = true; sc.radius = 1.5f;
        coin.AddComponent<Collectible>();
        SetColor(coin, C(1f, 0.82f, 0.1f));

        // Inner highlight disc
        var inner = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        inner.name = "Inner";
        inner.transform.SetParent(coin.transform);
        inner.transform.localPosition = V(0, 0.35f, 0);
        inner.transform.localScale = V(0.6f, 0.3f, 0.6f);
        Destroy(inner.GetComponent<Collider>());
        SetColor(inner, C(1f, 0.95f, 0.5f));
    }

    // ══════════ PLAYER (POTATO) ══════════

    private GameObject CreatePlayer()
    {
        var player = new GameObject("Player");
        player.transform.position = V(0, 1, 0);

        var capsule = player.AddComponent<CapsuleCollider>();
        capsule.height = 1.6f;
        capsule.radius = 0.45f;
        capsule.center = V(0, 0.8f, 0);

        // Zero friction
        var mat = new PhysicsMaterial("Potato");
        mat.dynamicFriction = 0; mat.staticFriction = 0;
        mat.frictionCombine = PhysicsMaterialCombine.Minimum;
        capsule.material = mat;

        Color potato = C(0.95f, 0.82f, 0.5f);
        Color dark = C(0.75f, 0.6f, 0.35f);

        // Body — potato shape (sphere stretched slightly)
        MakeSphere("Body", player.transform, V(0, 0.85f, 0), V(0.9f, 1.1f, 0.75f), potato);
        // Belly
        MakeSphere("Belly", player.transform, V(0, 0.75f, 0.15f), V(0.65f, 0.7f, 0.45f), C(1f, 0.9f, 0.65f));

        // Eyes
        MakeSphere("LEye", player.transform, V(-0.15f, 1.15f, 0.3f), V(0.18f, 0.22f, 0.1f), C(1, 1, 1));
        MakeSphere("REye", player.transform, V(0.15f, 1.15f, 0.3f), V(0.18f, 0.22f, 0.1f), C(1, 1, 1));
        MakeSphere("LPupil", player.transform, V(-0.15f, 1.15f, 0.36f), V(0.09f, 0.11f, 0.05f), C(0.08f, 0.08f, 0.12f));
        MakeSphere("RPupil", player.transform, V(0.15f, 1.15f, 0.36f), V(0.09f, 0.11f, 0.05f), C(0.08f, 0.08f, 0.12f));

        // Eyebrows
        MakeSphere("LBrow", player.transform, V(-0.15f, 1.28f, 0.32f), V(0.2f, 0.04f, 0.06f), dark);
        MakeSphere("RBrow", player.transform, V(0.15f, 1.28f, 0.32f), V(0.2f, 0.04f, 0.06f), dark);

        // Mouth (small dark sphere)
        MakeSphere("Mouth", player.transform, V(0, 0.98f, 0.38f), V(0.12f, 0.05f, 0.04f), C(0.6f, 0.3f, 0.25f));

        // Feet
        MakeSphere("LeftFoot", player.transform, V(-0.2f, 0.08f, 0.05f), V(0.22f, 0.14f, 0.3f), dark);
        MakeSphere("RightFoot", player.transform, V(0.2f, 0.08f, 0.05f), V(0.22f, 0.14f, 0.3f), dark);

        // Small arms (stubs)
        MakeSphere("LArm", player.transform, V(-0.48f, 0.85f, 0), V(0.18f, 0.12f, 0.15f), potato);
        MakeSphere("RArm", player.transform, V(0.48f, 0.85f, 0), V(0.18f, 0.12f, 0.15f), potato);

        // ── Physics ──
        var rb = player.AddComponent<Rigidbody>();
        rb.freezeRotation = true;
        rb.mass = 1f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;

        // Physics3DAdapter — FIXED ground check
        var adapter = player.AddComponent<Physics3DAdapter>();
        LayerMask gm = (1 << GROUND_LAYER);
        SetField(adapter, "groundLayer", gm);
        SetField(adapter, "groundCheckDistance", 0.15f);  // short ray below feet
        SetField(adapter, "groundCheckRadius", 0.2f);   // unused with raycast
        SetField(adapter, "groundCheckOffset", V(0, 0.1f, 0));  // start slightly above feet, ray goes 0.15 down

        // ModularJumpSystem
        var jump = player.AddComponent<ModularJumpSystem>();
        jump.enabled = false;
        SetField(jump, "dimensionMode", DimensionMode.Mode3D);
        SetField(jump, "maxJumps", 1);
        SetField(jump, "jumpForce", 9f);
        SetField(jump, "consistentJumpHeight", true);
        SetField(jump, "fallingGravityMultiplier", 3.5f);
        SetField(jump, "risingGravityMultiplier", 1.5f);
        SetField(jump, "coyoteTimeDuration", 0.12f);
        SetField(jump, "jumpBufferDuration", 0.1f);
        SetField(jump, "terminalVelocity", 22f);
        SetField(jump, "jumpInputAction", jumpAction);
        jump.enabled = true;

        var ctrl = player.AddComponent<PlayerController3D>();
        SetField(ctrl, "jumpSystem", jump);
        player.AddComponent<FallDetector>();
        player.AddComponent<CharacterAnimator>();

        return player;
    }

    // ══════════ CAMERA ══════════

    private void SetupCamera(Transform player)
    {
        var existing = FindAnyObjectByType<Camera>();
        if (existing != null) Destroy(existing.gameObject);

        var camObj = new GameObject("Main Camera");
        var cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        camObj.tag = "MainCamera";
        cam.orthographic = false;
        cam.fieldOfView = 55f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C(0.5f, 0.72f, 0.95f);
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 300f;
        cam.allowMSAA = true;
        // Disable post-processing for sharper image
        var camData = camObj.AddComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
        camData.renderPostProcessing = false;
        camData.antialiasing = UnityEngine.Rendering.Universal.AntialiasingMode.SubpixelMorphologicalAntiAliasing;
        camData.antialiasingQuality = UnityEngine.Rendering.Universal.AntialiasingQuality.High;
        camObj.transform.position = player.position + V(0, 5, -8);
        camObj.transform.LookAt(player.position);

        var follow = camObj.AddComponent<FollowCamera>();
        SetField(follow, "target", player);
        SetField(follow, "distance", 7f);
        SetField(follow, "height", 3.5f);
        SetField(follow, "mouseSensitivity", 2.5f);
        SetField(follow, "smoothSpeed", 12f);
    }

    // ══════════ HUD ══════════

    private void CreateHUD()
    {
        var canvas = new GameObject("HUD").AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvas.gameObject.AddComponent<UnityEngine.UI.CanvasScaler>();
        scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = V2(1920, 1080);

        var coinObj = MakeText(canvas.transform, "Coins", V2(0, 1), V2(0, 1), V2(90, -35), V2(200, 45));
        var tmp = coinObj.GetComponent<TMPro.TextMeshProUGUI>();
        tmp.text = "<color=#FFD700>\u25CF</color> 0";
        tmp.fontSize = 42;
        tmp.color = Color.white;
        tmp.alignment = TMPro.TextAlignmentOptions.Left;
        coinObj.AddComponent<CoinUIUpdater>();
    }

    private GameObject MakeText(Transform p, string n, Vector2 amin, Vector2 amax, Vector2 pos, Vector2 sz)
    {
        var o = new GameObject(n, typeof(RectTransform));
        o.transform.SetParent(p, false);
        var rt = o.GetComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.anchoredPosition = pos; rt.sizeDelta = sz;
        var t = o.AddComponent<TMPro.TextMeshProUGUI>();
        t.fontStyle = TMPro.FontStyles.Bold;
        t.outlineWidth = 0.25f;
        t.outlineColor = new Color32(0, 0, 0, 200);
        return o;
    }

    // ══════════ HELPERS ══════════

    private Vector3 V(float x, float y, float z) => new Vector3(x, y, z);
    private Vector2 V2(float x, float y) => new Vector2(x, y);
    private Color C(float r, float g, float b) => new Color(r, g, b);

    private GameObject Box(string n, Vector3 p, Vector3 s, Color c, int layer = -1, bool col = true)
    {
        var o = GameObject.CreatePrimitive(PrimitiveType.Cube);
        o.name = n; o.transform.position = p; o.transform.localScale = s;
        if (layer >= 0) o.layer = layer;
        if (!col) Destroy(o.GetComponent<Collider>());
        SetColor(o, c); return o;
    }

    private GameObject Sphere(string n, Vector3 p, Vector3 s, Color c, int layer = -1, bool col = false)
    {
        var o = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        o.name = n; o.transform.position = p; o.transform.localScale = s;
        if (layer >= 0) o.layer = layer;
        if (!col) Destroy(o.GetComponent<Collider>());
        SetColor(o, c); return o;
    }

    private GameObject MakeSphere(string n, Transform par, Vector3 lp, Vector3 ls, Color c)
    {
        var o = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        o.name = n;
        if (par != null) o.transform.SetParent(par);
        o.transform.localPosition = lp; o.transform.localScale = ls;
        Destroy(o.GetComponent<Collider>());
        SetColor(o, c); return o;
    }

    private GameObject Cyl(string n, Vector3 p, Vector3 s, Color c)
    {
        var o = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        o.name = n; o.transform.position = p; o.transform.localScale = s;
        Destroy(o.GetComponent<Collider>());
        SetColor(o, c); return o;
    }

    private void SetColor(GameObject o, Color c)
    {
        var r = o.GetComponent<Renderer>();
        if (r == null) return;
        var m = new Material(urpLit);
        m.color = c;
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.25f);
        r.material = m;
    }

    private void SetField(object t, string f, object v)
    {
        var fi = t.GetType().GetField(f,
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance |
            System.Reflection.BindingFlags.Public);
        if (fi != null) fi.SetValue(t, v);
    }
}
