using UnityEngine;

/// <summary>
/// Respawns the player if they fall below a Y threshold.
/// </summary>
public class FallDetector : MonoBehaviour
{
    [SerializeField] private float fallThreshold = -10f;
    private Vector3 spawnPoint;

    private void Start()
    {
        spawnPoint = transform.position;
    }

    private void Update()
    {
        if (transform.position.y < fallThreshold)
        {
            transform.position = spawnPoint;
            var rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.linearVelocity = Vector3.zero;
            }
        }
    }
}
