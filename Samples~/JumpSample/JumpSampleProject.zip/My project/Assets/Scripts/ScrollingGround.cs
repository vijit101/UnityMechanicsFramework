using UnityEngine;

public class ScrollingGround : MonoBehaviour
{
    [SerializeField] private float scrollSpeed = 3f;
    [SerializeField] private float resetOffsetX = 20f;

    private Vector3 startPos;
    private bool isScrolling;

    private void Start()
    {
        startPos = transform.position;

        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnGameStart += StartScrolling;
            FlappyGameManager.Instance.OnGameOver += StopScrolling;
        }
    }

    private void StartScrolling()
    {
        isScrolling = true;
    }

    private void StopScrolling()
    {
        isScrolling = false;
    }

    private void Update()
    {
        if (!isScrolling) return;

        transform.Translate(Vector3.left * (scrollSpeed * Time.deltaTime));

        // Wrap around when scrolled too far
        if (transform.position.x < startPos.x - resetOffsetX / 2f)
        {
            transform.position = startPos;
        }
    }

    private void OnDestroy()
    {
        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnGameStart -= StartScrolling;
            FlappyGameManager.Instance.OnGameOver -= StopScrolling;
        }
    }
}
