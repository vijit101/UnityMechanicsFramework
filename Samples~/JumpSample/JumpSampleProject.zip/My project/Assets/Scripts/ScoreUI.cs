using UnityEngine;
using TMPro;

public class ScoreUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI scoreText;

    private void Start()
    {
        if (scoreText != null)
        {
            scoreText.text = "0";
        }

        FlappyGameManager.Instance.OnScoreChanged += UpdateScore;
    }

    private void OnDestroy()
    {
        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnScoreChanged -= UpdateScore;
        }
    }

    private void UpdateScore(int score)
    {
        if (scoreText != null)
        {
            scoreText.text = score.ToString();
        }
    }
}
