using UnityEngine;

/// <summary>
/// Makes the ground look like classic Flappy Bird: brown dirt with a green grass strip on top.
/// Attach to the Ground GameObject.
/// </summary>
public class GroundVisuals : MonoBehaviour
{
    private void Awake()
    {
        // Set ground to brown/sand color
        var body = GetComponent<SpriteRenderer>();
        if (body != null)
        {
            body.color = new Color(0.85f, 0.75f, 0.5f); // Sandy brown
            body.sortingOrder = 5;
        }

        // Create grass strip on top
        GameObject grass = new GameObject("GrassStrip");
        grass.transform.SetParent(transform, false);
        // Position at top edge of ground (ground scale Y=1, so top is at local 0.5)
        grass.transform.localPosition = new Vector3(0f, 0.45f, 0f);
        grass.transform.localScale = new Vector3(1f, 0.12f, 1f);

        var grassSr = grass.AddComponent<SpriteRenderer>();
        Texture2D tex = new Texture2D(4, 4);
        Color[] pixels = new Color[16];
        for (int i = 0; i < 16; i++) pixels[i] = Color.white;
        tex.SetPixels(pixels);
        tex.Apply();
        grassSr.sprite = Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f), 4f);
        grassSr.color = new Color(0.35f, 0.8f, 0.2f); // Bright green
        grassSr.sortingOrder = 6;
    }
}
