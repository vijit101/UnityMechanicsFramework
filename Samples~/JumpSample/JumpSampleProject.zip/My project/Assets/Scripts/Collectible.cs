using UnityEngine;

public class Collectible : MonoBehaviour
{
    private float bobSpeed = 2f;
    private float bobHeight = 0.25f;

    private Vector3 startPos;
    private static int totalCollected;
    public static int TotalCollected => totalCollected;
    public static event System.Action<int> OnCollected;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics() { totalCollected = 0; }

    private void Start()
    {
        startPos = transform.position;
    }

    private void Update()
    {
        // Spin around Y axis (upright spin like a real coin)
        transform.Rotate(Vector3.forward, 120f * Time.deltaTime, Space.Self);

        // Bob up and down
        float newY = startPos.y + Mathf.Sin(Time.time * bobSpeed + startPos.x) * bobHeight;
        transform.position = new Vector3(startPos.x, newY, startPos.z);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<PlayerController3D>() != null ||
            other.GetComponentInParent<PlayerController3D>() != null)
        {
            totalCollected++;
            OnCollected?.Invoke(totalCollected);
            Destroy(gameObject);
        }
    }
}
