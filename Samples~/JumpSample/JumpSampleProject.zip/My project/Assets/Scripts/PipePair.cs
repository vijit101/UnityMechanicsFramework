using UnityEngine;

public class PipePair : MonoBehaviour
{
    private float speed;
    private const float DESTROY_X = -15f;

    public void Initialize(float moveSpeed)
    {
        speed = moveSpeed;
    }

    private void Update()
    {
        if (FlappyGameManager.Instance != null && FlappyGameManager.Instance.CurrentState == GameState.GameOver) return;

        transform.Translate(Vector3.left * (speed * Time.deltaTime));

        if (transform.position.x < DESTROY_X)
        {
            Destroy(gameObject);
        }
    }
}
