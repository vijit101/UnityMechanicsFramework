using UnityEngine;

/// <summary>
/// Procedural animation for a potato character.
/// Squashes on land, stretches on jump, wobbles when moving.
/// </summary>
public class CharacterAnimator : MonoBehaviour
{
    private Rigidbody rb;
    private Transform body;
    private Transform leftFoot, rightFoot;
    private Vector3 bodyBaseScale;
    private bool wasGrounded;
    private float squashTimer;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        body = transform.Find("Body");
        leftFoot = transform.Find("LeftFoot");
        rightFoot = transform.Find("RightFoot");
        if (body != null) bodyBaseScale = body.localScale;
    }

    private void Update()
    {
        if (body == null || rb == null) return;

        float speed = new Vector2(rb.linearVelocity.x, rb.linearVelocity.z).magnitude;
        float velY = rb.linearVelocity.y;
        bool isMoving = speed > 0.5f;

        // Squash & stretch
        Vector3 targetScale = bodyBaseScale;
        if (squashTimer > 0f)
        {
            // Landing squash
            float t = squashTimer / 0.15f;
            targetScale = new Vector3(bodyBaseScale.x * (1f + 0.2f * t), bodyBaseScale.y * (1f - 0.15f * t), bodyBaseScale.z * (1f + 0.2f * t));
            squashTimer -= Time.deltaTime;
        }
        else if (velY > 2f)
        {
            // Rising stretch
            float stretch = Mathf.Clamp01(velY / 10f) * 0.15f;
            targetScale = new Vector3(bodyBaseScale.x * (1f - stretch), bodyBaseScale.y * (1f + stretch * 1.5f), bodyBaseScale.z * (1f - stretch));
        }
        else if (velY < -2f)
        {
            // Falling stretch
            float stretch = Mathf.Clamp01(-velY / 10f) * 0.1f;
            targetScale = new Vector3(bodyBaseScale.x * (1f + stretch * 0.5f), bodyBaseScale.y * (1f - stretch), bodyBaseScale.z * (1f + stretch * 0.5f));
        }

        body.localScale = Vector3.Lerp(body.localScale, targetScale, Time.deltaTime * 12f);

        // Body tilt when moving
        float tiltAngle = isMoving ? Mathf.Sin(Time.time * 8f) * 3f : 0f;
        body.localRotation = Quaternion.Euler(isMoving ? 8f : 0f, 0f, tiltAngle);

        // Foot animation
        if (leftFoot != null && rightFoot != null)
        {
            float swing = isMoving ? Mathf.Sin(Time.time * 10f) * 0.15f : 0f;
            leftFoot.localPosition = new Vector3(leftFoot.localPosition.x, 0.08f, swing);
            rightFoot.localPosition = new Vector3(rightFoot.localPosition.x, 0.08f, -swing);
        }

        // Detect landing
        bool grounded = rb.linearVelocity.y > -0.1f && rb.linearVelocity.y < 0.1f && wasGrounded == false && velY >= -0.5f;
        // Simple ground check for animation
        if (!wasGrounded && Mathf.Abs(velY) < 0.5f && speed < 1f)
        {
            squashTimer = 0.15f;
        }
        wasGrounded = Mathf.Abs(velY) < 0.5f;
    }
}
