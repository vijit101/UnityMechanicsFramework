using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum GameState
{
    Ready,
    Playing,
    GameOver
}

public class FlappyGameManager : MonoBehaviour
{
    public static FlappyGameManager Instance { get; private set; }

    public event Action OnGameStart;
    public event Action OnGameOver;
    public event Action<int> OnScoreChanged;

    public GameState CurrentState { get; private set; } = GameState.Ready;
    public int Score { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void StartGame()
    {
        if (CurrentState != GameState.Ready) return;

        CurrentState = GameState.Playing;
        Score = 0;
        OnScoreChanged?.Invoke(Score);
        OnGameStart?.Invoke();
    }

    public void TriggerGameOver()
    {
        if (CurrentState != GameState.Playing) return;

        CurrentState = GameState.GameOver;
        OnGameOver?.Invoke();
    }

    public void AddScore()
    {
        if (CurrentState != GameState.Playing) return;

        Score++;
        OnScoreChanged?.Invoke(Score);
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    private void OnDestroy()
    {
        if (Instance == this)
        {
            Instance = null;
        }
    }
}
