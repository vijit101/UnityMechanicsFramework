using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class GameUI : MonoBehaviour
{
    [Header("Panels")]
    [SerializeField] private GameObject startPanel;
    [SerializeField] private GameObject gameOverPanel;

    [Header("Game Over UI")]
    [SerializeField] private TextMeshProUGUI finalScoreText;

    [Header("Input")]
    [SerializeField] private InputActionReference restartAction;

    private bool waitingForRestart;
    private float restartDelay;

    private void Start()
    {
        ShowStartScreen();

        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnGameStart += OnGameStart;
            FlappyGameManager.Instance.OnGameOver += OnGameOver;
        }
    }

    private void Update()
    {
        // Handle restart input directly in Update to avoid timeScale issues
        if (waitingForRestart)
        {
            restartDelay -= Time.unscaledDeltaTime;
            if (restartDelay <= 0f && Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame)
            {
                FlappyGameManager.Instance.RestartGame();
            }
        }
    }

    private void OnDestroy()
    {
        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnGameStart -= OnGameStart;
            FlappyGameManager.Instance.OnGameOver -= OnGameOver;
        }
    }

    private void ShowStartScreen()
    {
        if (startPanel != null) startPanel.SetActive(true);
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    private void OnGameStart()
    {
        if (startPanel != null) startPanel.SetActive(false);
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    private void OnGameOver()
    {
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
        if (finalScoreText != null)
        {
            finalScoreText.text = "Score: " + FlappyGameManager.Instance.Score;
        }
        // Small delay before accepting restart to prevent accidental restart
        waitingForRestart = true;
        restartDelay = 0.5f;
    }
}
