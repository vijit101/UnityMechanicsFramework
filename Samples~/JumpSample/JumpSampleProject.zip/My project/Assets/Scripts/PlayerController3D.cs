using UnityEngine;
using UnityEngine.InputSystem;
using GameplayMechanicsUMFOSS.Movement;

public class PlayerController3D : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 7f;
    [SerializeField] private float acceleration = 50f;
    [SerializeField] private float deceleration = 40f;
    [SerializeField] private float rotationSpeed = 15f;

    [Header("References")]
    [SerializeField] private ModularJumpSystem jumpSystem;

    private Rigidbody rb;
    private Vector2 moveInput;
    private PhysicsMaterial zeroFriction;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true;

        // Zero-friction physics material to prevent sticking on platform edges
        zeroFriction = new PhysicsMaterial("PlayerFriction");
        zeroFriction.dynamicFriction = 0f;
        zeroFriction.staticFriction = 0f;
        zeroFriction.frictionCombine = PhysicsMaterialCombine.Minimum;
        zeroFriction.bounceCombine = PhysicsMaterialCombine.Minimum;

        var collider = GetComponent<CapsuleCollider>();
        if (collider != null)
        {
            collider.material = zeroFriction;
        }
    }

    private void Update()
    {
        moveInput = Vector2.zero;
        if (Keyboard.current != null)
        {
            if (Keyboard.current.wKey.isPressed) moveInput.y += 1f;
            if (Keyboard.current.sKey.isPressed) moveInput.y -= 1f;
            if (Keyboard.current.aKey.isPressed) moveInput.x -= 1f;
            if (Keyboard.current.dKey.isPressed) moveInput.x += 1f;
            if (moveInput.sqrMagnitude > 1f) moveInput.Normalize();
        }
    }

    private void FixedUpdate()
    {
        float airControl = (jumpSystem != null && !jumpSystem.IsGrounded)
            ? jumpSystem.AirControlModifier
            : 1f;

        // Camera-relative movement
        Vector3 forward = Vector3.forward;
        Vector3 right = Vector3.right;

        Camera cam = Camera.main;
        if (cam != null)
        {
            forward = cam.transform.forward;
            right = cam.transform.right;
            forward.y = 0f;
            right.y = 0f;
            forward.Normalize();
            right.Normalize();
        }

        Vector3 targetVelocity = (forward * moveInput.y + right * moveInput.x) * (moveSpeed * airControl);
        Vector3 currentHorizontal = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z);

        // Smooth acceleration/deceleration
        float accel = (moveInput.sqrMagnitude > 0.01f) ? acceleration : deceleration;
        Vector3 newHorizontal = Vector3.MoveTowards(currentHorizontal, targetVelocity, accel * Time.fixedDeltaTime);

        rb.linearVelocity = new Vector3(newHorizontal.x, rb.linearVelocity.y, newHorizontal.z);

        // Rotate player toward movement direction
        if (targetVelocity.sqrMagnitude > 0.01f)
        {
            Quaternion targetRot = Quaternion.LookRotation(targetVelocity.normalized);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Time.fixedDeltaTime * rotationSpeed);
        }
    }
}
