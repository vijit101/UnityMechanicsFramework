using UnityEngine;

public class PipeSpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    [SerializeField] private float spawnInterval = 1.8f;
    [SerializeField] private float spawnX = 12f;

    [Header("Pipe Settings")]
    [SerializeField] private float pipeSpeed = 3f;
    [SerializeField] private float gapSize = 3f;
    [SerializeField] private float heightVariation = 2f;
    [SerializeField] private float gapCenterBase = 0f;

    [Header("Pipe Colors")]
    [SerializeField] private Color pipeBodyColor = new Color(0.3f, 0.75f, 0.2f);
    [SerializeField] private Color pipeCapColor = new Color(0.2f, 0.6f, 0.15f);
    [SerializeField] private Color pipeOutlineColor = new Color(0.15f, 0.45f, 0.1f);

    private float spawnTimer;
    private bool isSpawning;
    private Sprite pipeSprite;

    private void Start()
    {
        Texture2D tex = new Texture2D(4, 4);
        Color[] pixels = new Color[16];
        for (int i = 0; i < 16; i++) pixels[i] = Color.white;
        tex.SetPixels(pixels);
        tex.Apply();
        pipeSprite = Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f), 4f);

        FlappyGameManager.Instance.OnGameStart += StartSpawning;
        FlappyGameManager.Instance.OnGameOver += StopSpawning;
    }

    private void OnDestroy()
    {
        if (FlappyGameManager.Instance != null)
        {
            FlappyGameManager.Instance.OnGameStart -= StartSpawning;
            FlappyGameManager.Instance.OnGameOver -= StopSpawning;
        }
    }

    private void StartSpawning()
    {
        isSpawning = true;
        spawnTimer = 0.5f;
    }

    private void StopSpawning()
    {
        isSpawning = false;
    }

    private void Update()
    {
        if (!isSpawning) return;

        spawnTimer -= Time.deltaTime;
        if (spawnTimer <= 0f)
        {
            SpawnPipe();
            spawnTimer = spawnInterval;
        }
    }

    private void SpawnPipe()
    {
        GameObject pipePair = new GameObject("PipePair");
        pipePair.transform.position = new Vector3(spawnX, 0f, 0f);

        float gapCenterY = gapCenterBase + Random.Range(-heightVariation, heightVariation);
        float pipeHeight = 10f;
        float pipeWidth = 1.3f;
        float capWidth = 1.6f;
        float capHeight = 0.5f;

        // Top pipe: body + cap at bottom end + outline
        float topPipeY = gapCenterY + gapSize / 2f + pipeHeight / 2f;
        CreatePipeBody("TopPipe", pipePair.transform,
            new Vector3(0f, topPipeY, 0f),
            new Vector3(pipeWidth, pipeHeight, 1f));
        // Top pipe outline (slightly larger behind)
        CreateSprite("TopPipeOutline", pipePair.transform,
            new Vector3(0f, topPipeY, 0.1f),
            new Vector3(pipeWidth + 0.15f, pipeHeight + 0.05f, 1f),
            pipeOutlineColor, -1);
        // Top pipe cap (at the bottom end of top pipe)
        float topCapY = gapCenterY + gapSize / 2f + capHeight / 2f;
        CreateSprite("TopPipeCap", pipePair.transform,
            new Vector3(0f, topCapY, 0f),
            new Vector3(capWidth, capHeight, 1f),
            pipeCapColor, 2);
        // Top cap outline
        CreateSprite("TopPipeCapOutline", pipePair.transform,
            new Vector3(0f, topCapY, 0.1f),
            new Vector3(capWidth + 0.12f, capHeight + 0.1f, 1f),
            pipeOutlineColor, -1);

        // Bottom pipe: body + cap at top end + outline
        float bottomPipeY = gapCenterY - gapSize / 2f - pipeHeight / 2f;
        CreatePipeBody("BottomPipe", pipePair.transform,
            new Vector3(0f, bottomPipeY, 0f),
            new Vector3(pipeWidth, pipeHeight, 1f));
        // Bottom pipe outline
        CreateSprite("BottomPipeOutline", pipePair.transform,
            new Vector3(0f, bottomPipeY, 0.1f),
            new Vector3(pipeWidth + 0.15f, pipeHeight + 0.05f, 1f),
            pipeOutlineColor, -1);
        // Bottom pipe cap (at the top end of bottom pipe)
        float bottomCapY = gapCenterY - gapSize / 2f - capHeight / 2f;
        CreateSprite("BottomPipeCap", pipePair.transform,
            new Vector3(0f, bottomCapY, 0f),
            new Vector3(capWidth, capHeight, 1f),
            pipeCapColor, 2);
        // Bottom cap outline
        CreateSprite("BottomPipeCapOutline", pipePair.transform,
            new Vector3(0f, bottomCapY, 0.1f),
            new Vector3(capWidth + 0.12f, capHeight + 0.1f, 1f),
            pipeOutlineColor, -1);

        // Score zone (trigger) — invisible
        GameObject scoreZone = new GameObject("ScoreZone");
        scoreZone.transform.SetParent(pipePair.transform);
        scoreZone.transform.localPosition = new Vector3(0f, gapCenterY, 0f);
        scoreZone.transform.localScale = new Vector3(0.5f, gapSize, 1f);
        var scoreTrigger = scoreZone.AddComponent<BoxCollider2D>();
        scoreTrigger.isTrigger = true;
        scoreZone.AddComponent<ScoreZone>();

        var pair = pipePair.AddComponent<PipePair>();
        pair.Initialize(pipeSpeed);
    }

    private void CreatePipeBody(string name, Transform parent, Vector3 localPos, Vector3 localScale)
    {
        GameObject pipe = new GameObject(name);
        pipe.transform.SetParent(parent);
        pipe.transform.localPosition = localPos;
        pipe.transform.localScale = localScale;

        var sr = pipe.AddComponent<SpriteRenderer>();
        sr.sprite = pipeSprite;
        sr.color = pipeBodyColor;
        sr.sortingOrder = 1;

        pipe.AddComponent<BoxCollider2D>();
    }

    private void CreateSprite(string name, Transform parent, Vector3 localPos, Vector3 localScale, Color color, int sortingOrder)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent);
        obj.transform.localPosition = localPos;
        obj.transform.localScale = localScale;

        var sr = obj.AddComponent<SpriteRenderer>();
        sr.sprite = pipeSprite;
        sr.color = color;
        sr.sortingOrder = sortingOrder;
    }
}
