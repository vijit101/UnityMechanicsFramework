using UnityEngine;

/// <summary>
/// Adds visual details to the bird: yellow body, eye, beak.
/// Attach to the Bird GameObject alongside the SpriteRenderer.
/// </summary>
public class BirdVisuals : MonoBehaviour
{
    private void Awake()
    {
        // Set bird body to yellow
        var body = GetComponent<SpriteRenderer>();
        if (body != null)
        {
            body.color = new Color(1f, 0.85f, 0.1f); // Flappy yellow
            body.sortingOrder = 10;
        }

        CreateEye();
        CreateBeak();
        CreateWing();
    }

    private void CreateEye()
    {
        GameObject eye = new GameObject("Eye");
        eye.transform.SetParent(transform, false);
        eye.transform.localPosition = new Vector3(0.15f, 0.12f, 0f);
        eye.transform.localScale = new Vector3(0.3f, 0.3f, 1f);

        var sr = eye.AddComponent<SpriteRenderer>();
        sr.sprite = CreateCircleSprite();
        sr.color = Color.white;
        sr.sortingOrder = 11;

        // Pupil
        GameObject pupil = new GameObject("Pupil");
        pupil.transform.SetParent(eye.transform, false);
        pupil.transform.localPosition = new Vector3(0.15f, 0.05f, 0f);
        pupil.transform.localScale = new Vector3(0.5f, 0.5f, 1f);

        var pupilSr = pupil.AddComponent<SpriteRenderer>();
        pupilSr.sprite = CreateCircleSprite();
        pupilSr.color = Color.black;
        pupilSr.sortingOrder = 12;
    }

    private void CreateBeak()
    {
        GameObject beak = new GameObject("Beak");
        beak.transform.SetParent(transform, false);
        beak.transform.localPosition = new Vector3(0.35f, -0.02f, 0f);
        beak.transform.localScale = new Vector3(0.35f, 0.2f, 1f);

        var sr = beak.AddComponent<SpriteRenderer>();
        sr.sprite = CreateSquareSprite();
        sr.color = new Color(0.9f, 0.4f, 0.1f); // Orange beak
        sr.sortingOrder = 11;
    }

    private void CreateWing()
    {
        GameObject wing = new GameObject("Wing");
        wing.transform.SetParent(transform, false);
        wing.transform.localPosition = new Vector3(-0.1f, -0.05f, 0f);
        wing.transform.localScale = new Vector3(0.35f, 0.25f, 1f);

        var sr = wing.AddComponent<SpriteRenderer>();
        sr.sprite = CreateCircleSprite();
        sr.color = new Color(0.9f, 0.7f, 0.05f); // Darker yellow wing
        sr.sortingOrder = 11;
    }

    private static Sprite cachedCircle;
    private static Sprite CreateCircleSprite()
    {
        if (cachedCircle != null) return cachedCircle;

        int size = 64;
        Texture2D tex = new Texture2D(size, size);
        tex.filterMode = FilterMode.Bilinear;
        float center = size / 2f;
        float radius = size / 2f;

        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                tex.SetPixel(x, y, dist <= radius ? Color.white : Color.clear);
            }
        }
        tex.Apply();
        cachedCircle = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        return cachedCircle;
    }

    private static Sprite cachedSquare;
    private static Sprite CreateSquareSprite()
    {
        if (cachedSquare != null) return cachedSquare;

        int size = 8;
        Texture2D tex = new Texture2D(size, size);
        Color[] pixels = new Color[size * size];
        for (int i = 0; i < pixels.Length; i++) pixels[i] = Color.white;
        tex.SetPixels(pixels);
        tex.Apply();
        cachedSquare = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        return cachedSquare;
    }
}
