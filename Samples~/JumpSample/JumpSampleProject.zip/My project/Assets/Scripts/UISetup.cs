using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Auto-configures the entire game UI layout on Awake.
/// Attach to the Canvas. It will find or create all needed UI elements.
/// </summary>
public class UISetup : MonoBehaviour
{
    [Header("Auto-Generated References (don't assign manually)")]
    public TextMeshProUGUI scoreText;
    public GameObject startPanel;
    public GameObject gameOverPanel;
    public TextMeshProUGUI finalScoreText;

    [Header("Input")]
    [SerializeField] private UnityEngine.InputSystem.InputActionReference restartAction;

    private void Awake()
    {
        // Clean up any existing children
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        // Set Canvas Scaler
        var scaler = GetComponent<CanvasScaler>();
        if (scaler != null)
        {
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.matchWidthOrHeight = 0.5f;
        }

        CreateScoreText();
        CreateStartPanel();
        CreateGameOverPanel();

        // Wire up ScoreUI
        var scoreUI = GetComponent<ScoreUI>();
        if (scoreUI == null) scoreUI = gameObject.AddComponent<ScoreUI>();
        SetPrivateField(scoreUI, "scoreText", scoreText);

        // Wire up GameUI
        var gameUI = GetComponent<GameUI>();
        if (gameUI == null) gameUI = gameObject.AddComponent<GameUI>();
        SetPrivateField(gameUI, "startPanel", startPanel);
        SetPrivateField(gameUI, "gameOverPanel", gameOverPanel);
        SetPrivateField(gameUI, "finalScoreText", finalScoreText);
        SetPrivateField(gameUI, "restartAction", restartAction);
    }

    private void CreateScoreText()
    {
        GameObject obj = CreateUIElement("ScoreText", transform);
        RectTransform rt = obj.GetComponent<RectTransform>();
        SetAnchors(rt, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f));
        rt.anchoredPosition = new Vector2(0f, -120f);
        rt.sizeDelta = new Vector2(300f, 100f);

        scoreText = obj.AddComponent<TextMeshProUGUI>();
        scoreText.text = "0";
        scoreText.fontSize = 96;
        scoreText.fontStyle = FontStyles.Bold;
        scoreText.alignment = TextAlignmentOptions.Center;
        scoreText.color = Color.white;
        scoreText.outlineWidth = 0.25f;
        scoreText.outlineColor = new Color32(50, 50, 50, 200);
    }

    private void CreateStartPanel()
    {
        startPanel = CreateUIElement("StartPanel", transform);
        RectTransform rt = startPanel.GetComponent<RectTransform>();
        StretchFull(rt);

        // Title text
        GameObject title = CreateUIElement("TitleText", startPanel.transform);
        RectTransform titleRt = title.GetComponent<RectTransform>();
        SetAnchors(titleRt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f));
        titleRt.anchoredPosition = new Vector2(0f, 150f);
        titleRt.sizeDelta = new Vector2(600f, 120f);

        var titleTmp = title.AddComponent<TextMeshProUGUI>();
        titleTmp.text = "Flappy Bird";
        titleTmp.fontSize = 72;
        titleTmp.fontStyle = FontStyles.Bold;
        titleTmp.alignment = TextAlignmentOptions.Center;
        titleTmp.color = Color.white;
        titleTmp.outlineWidth = 0.3f;
        titleTmp.outlineColor = new Color32(40, 40, 40, 200);

        // Instruction text
        GameObject instr = CreateUIElement("InstructionText", startPanel.transform);
        RectTransform instrRt = instr.GetComponent<RectTransform>();
        SetAnchors(instrRt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f));
        instrRt.anchoredPosition = new Vector2(0f, -50f);
        instrRt.sizeDelta = new Vector2(500f, 80f);

        var instrTmp = instr.AddComponent<TextMeshProUGUI>();
        instrTmp.text = "Press SPACE to Start";
        instrTmp.fontSize = 40;
        instrTmp.fontStyle = FontStyles.Bold;
        instrTmp.alignment = TextAlignmentOptions.Center;
        instrTmp.color = new Color(1f, 1f, 1f, 0.9f);
        instrTmp.outlineWidth = 0.2f;
        instrTmp.outlineColor = new Color32(40, 40, 40, 180);
    }

    private void CreateGameOverPanel()
    {
        gameOverPanel = CreateUIElement("GameOverPanel", transform);
        RectTransform rt = gameOverPanel.GetComponent<RectTransform>();
        StretchFull(rt);

        // Dark overlay
        var img = gameOverPanel.AddComponent<Image>();
        img.color = new Color(0f, 0f, 0f, 0.45f);

        // "Game Over" title
        GameObject goTitle = CreateUIElement("GameOverTitle", gameOverPanel.transform);
        RectTransform goRt = goTitle.GetComponent<RectTransform>();
        SetAnchors(goRt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f));
        goRt.anchoredPosition = new Vector2(0f, 150f);
        goRt.sizeDelta = new Vector2(600f, 120f);

        var goTmp = goTitle.AddComponent<TextMeshProUGUI>();
        goTmp.text = "Game Over";
        goTmp.fontSize = 72;
        goTmp.fontStyle = FontStyles.Bold;
        goTmp.alignment = TextAlignmentOptions.Center;
        goTmp.color = Color.white;
        goTmp.outlineWidth = 0.3f;
        goTmp.outlineColor = new Color32(40, 40, 40, 200);

        // Score
        GameObject scoreObj = CreateUIElement("FinalScore", gameOverPanel.transform);
        RectTransform scoreRt = scoreObj.GetComponent<RectTransform>();
        SetAnchors(scoreRt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f));
        scoreRt.anchoredPosition = new Vector2(0f, 30f);
        scoreRt.sizeDelta = new Vector2(400f, 80f);

        finalScoreText = scoreObj.AddComponent<TextMeshProUGUI>();
        finalScoreText.text = "Score: 0";
        finalScoreText.fontSize = 52;
        finalScoreText.fontStyle = FontStyles.Bold;
        finalScoreText.alignment = TextAlignmentOptions.Center;
        finalScoreText.color = new Color(1f, 0.9f, 0.3f); // Gold
        finalScoreText.outlineWidth = 0.2f;
        finalScoreText.outlineColor = new Color32(40, 40, 40, 180);

        // Restart instruction
        GameObject restart = CreateUIElement("RestartText", gameOverPanel.transform);
        RectTransform restartRt = restart.GetComponent<RectTransform>();
        SetAnchors(restartRt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f));
        restartRt.anchoredPosition = new Vector2(0f, -80f);
        restartRt.sizeDelta = new Vector2(500f, 60f);

        var restartTmp = restart.AddComponent<TextMeshProUGUI>();
        restartTmp.text = "Press SPACE to Restart";
        restartTmp.fontSize = 36;
        restartTmp.fontStyle = FontStyles.Bold;
        restartTmp.alignment = TextAlignmentOptions.Center;
        restartTmp.color = new Color(1f, 1f, 1f, 0.85f);
        restartTmp.outlineWidth = 0.2f;
        restartTmp.outlineColor = new Color32(40, 40, 40, 180);

        gameOverPanel.SetActive(false);
    }

    // ── Helpers ──

    private GameObject CreateUIElement(string name, Transform parent)
    {
        GameObject obj = new GameObject(name, typeof(RectTransform));
        obj.transform.SetParent(parent, false);
        return obj;
    }

    private void SetAnchors(RectTransform rt, Vector2 anchorMin, Vector2 anchorMax)
    {
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = new Vector2(0.5f, 0.5f);
    }

    private void StretchFull(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
    }

    private void SetPrivateField(object target, string fieldName, object value)
    {
        var field = target.GetType().GetField(fieldName,
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
        if (field != null)
        {
            field.SetValue(target, value);
        }
    }
}
