using UnityEngine;

public class ScoreZone : MonoBehaviour
{
    private bool scored;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (scored) return;

        scored = true;
        FlappyGameManager.Instance.AddScore();
    }
}
