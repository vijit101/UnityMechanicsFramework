using System.Collections.Generic;
using UnityEngine;
using GameplayMechanicsUMFOSS.World;

public class RuntimeSetup : MonoBehaviour
{
    public SpawnProfile_UMFOSS profile;

    void Start()
    {
        var spGo = new GameObject("SpawnPoint");
        spGo.transform.position = Vector3.zero;
        var sp = spGo.AddComponent<SpawnPoint_UMFOSS>();
        sp.Configure(SpawnShape.Circle, radius: 3f);

        var tsGo = new GameObject("RuntimeTimedSpawner");
        var ts = tsGo.AddComponent<TimedSpawner_UMFOSS>();
        ts.Configure(
            profile: profile,
            spawnPoints: new List<SpawnPoint_UMFOSS> { sp },
            interval: 1.5f,
            maxActive: 5,
            spawnOnStart: true);
    }
}
