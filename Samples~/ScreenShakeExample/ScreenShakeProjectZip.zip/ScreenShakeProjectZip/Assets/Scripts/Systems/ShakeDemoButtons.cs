using UnityEngine;
using GameplayMechanicsUMFOSS.Systems;

public class ShakeButton : MonoBehaviour
{
    [SerializeField] public float magnitude ;
    [SerializeField] public float duration ;

    public void Trigger()
{
    if (ScreenShakeSystem_UMFOSS.Instance == null)
    {
        Debug.LogError("ShakeSystem Instance is NULL!");
        return;
    }

    ScreenShakeSystem_UMFOSS.Instance.TriggerShake(magnitude, duration);
}
}
