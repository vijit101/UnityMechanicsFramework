using UnityEngine;
using UnityEngine.UI;
using GameplayMechanicsUMFOSS.Inventory;
using TMPro; // Assuming TextMeshPro is typically used in modern Unity projects

namespace GameplayMechanicsUMFOSS.Samples.Inventory
{
    public class DemoInventoryUI_UMFOSS : MonoBehaviour
    {
        [Header("Inventory Ref")]
        [SerializeField] private InventorySystem_UMFOSS inventorySystem;

        [Header("Item Databse")]
        [SerializeField] private ItemData_UMFOSS healthPotion;
        [SerializeField] private ItemData_UMFOSS ironSword;
        [SerializeField] private ItemData_UMFOSS goldCoin;

        [Header("UI Grids")]
        [SerializeField] private Transform slotGridContainer;
        [SerializeField] private GameObject slotPrefab;
        [SerializeField] private TMP_Text inventoryFullMessage;
        [SerializeField] private TMP_Text weightDisplay;

        private GameObject[] uiSlots;

        private void Start()
        {
            if (inventorySystem == null) return;

            // Subscribe to Events
            inventorySystem.OnSlotChanged += UpdateSlotUI;
            inventorySystem.OnInventoryFull += ShowInventoryFullMessage;
            inventorySystem.OnWeightChanged += UpdateWeightDisplay;
            inventorySystem.OnInventoryCleared += RefreshAllSlots;

            InitializeUI();
        }

        private void InitializeUI()
        {
            int slotCount = inventorySystem.GetAllSlots().Count;
            uiSlots = new GameObject[slotCount];

            for (int i = 0; i < slotCount; i++)
            {
                uiSlots[i] = Instantiate(slotPrefab, slotGridContainer);
                UpdateSlotUI(i);
            }

            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            UpdateWeightDisplay(inventorySystem.GetCurrentWeight(), 0);
        }

        // --- Methods to be hooked into UI Buttons via Inspector ---

        public void AddHealthPotion()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            inventorySystem.AddItem(healthPotion, 1);
        }

        public void AddIronSword()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            inventorySystem.AddItem(ironSword, 1);
        }

        public void AddGoldCoins()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            inventorySystem.AddItem(goldCoin, 10);
        }

        public void RemoveHealthPotion()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            bool success = inventorySystem.RemoveItem(healthPotion, 1);
            if (!success)
            {
                Debug.Log("Could not remove Health Potion - none found!");
            }
        }

        public void SwapSlot0And1()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            inventorySystem.SwapSlots(0, 1);
        }

        public void ClearInventory()
        {
            if (inventoryFullMessage != null) inventoryFullMessage.text = "";
            inventorySystem.ClearInventory();
        }

        // --- UI Updating Methods ---

        private void UpdateSlotUI(int slotIndex)
        {
            if (uiSlots == null || slotIndex < 0 || slotIndex >= uiSlots.Length) return;

            var slotData = inventorySystem.GetSlotByIndex(slotIndex);
            var uiSlotObj = uiSlots[slotIndex];

            // Assuming prefab has an Image child and a TMP_Text child.
            // E.g., [1] image component on child 0, text component on child 1.
            Image iconImage = uiSlotObj.transform.GetChild(0).GetComponent<Image>();
            TMP_Text qtyText = uiSlotObj.GetComponentInChildren<TMP_Text>();

            if (slotData.IsEmpty())
            {
                iconImage.sprite = null;
                iconImage.color = new Color(0, 0, 0, 0); // Hide icon
                if (qtyText != null) qtyText.text = "";
            }
            else
            {
                iconImage.sprite = slotData.item.data.icon;
                iconImage.color = Color.white; // Show icon

                if (qtyText != null)
                {
                    qtyText.text = slotData.item.quantity >= 1 ? slotData.item.quantity.ToString() : "";
                }
            }
        }

        private void ShowInventoryFullMessage()
        {
            if (inventoryFullMessage != null)
            {
                inventoryFullMessage.text = "Inventory Full!";
            }
        }

        private void UpdateWeightDisplay(float current, float max)
        {
            if (weightDisplay != null)
            {
                weightDisplay.text = max > 0 ? $"Weight: {current}/{max}" : "Weight System Disabled";
            }
        }

        private void RefreshAllSlots()
        {
            for (int i = 0; i < uiSlots.Length; i++)
            {
                UpdateSlotUI(i);
            }
        }

        private void OnDestroy()
        {
            if (inventorySystem != null)
            {
                inventorySystem.OnSlotChanged -= UpdateSlotUI;
                inventorySystem.OnInventoryFull -= ShowInventoryFullMessage;
                inventorySystem.OnWeightChanged -= UpdateWeightDisplay;
                inventorySystem.OnInventoryCleared -= RefreshAllSlots;
            }
        }
    }
}
