using UnityEngine;
using UnityEngine.SceneManagement;
using GameplayMechanicsUMFOSS.Core;
using GameplayMechanicsUMFOSS.Systems;

public static class BulletTimeDemoAutoBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Bootstrap()
    {
        if (Object.FindFirstObjectByType<BulletTimeDemoBootstrapper>() != null)
            return;

        GameObject root = new GameObject("BulletTime Demo Bootstrapper");
        root.AddComponent<BulletTimeDemoBootstrapper>();
    }
}

public class BulletTimeDemoBootstrapper : MonoBehaviour
{
    private BulletTimeSystem_UMFOSS bulletTime;
    private PauseSystem_UMFOSS pauseSystem;
    private SlowMoConfig_UMFOSS subtleConfig;
    private SlowMoConfig_UMFOSS standardConfig;
    private SlowMoConfig_UMFOSS cinematicConfig;
    private Texture2D fillTexture;
    private AudioSource musicSource;
    private float uiTimer;
    private float resourceMax = 100f;
    private string lastEvent = "None";

    private void Awake()
    {
        BuildTextures();
        BuildConfigs();
        RebuildDemoWorld();
        Subscribe();
    }

    private void OnDestroy()
    {
        Unsubscribe();
    }

    private void Update()
    {
        uiTimer += Time.unscaledDeltaTime;

        if (Input.GetKeyDown(KeyCode.Alpha1)) bulletTime.Enter(subtleConfig);
        if (Input.GetKeyDown(KeyCode.Alpha2)) bulletTime.Enter(standardConfig);
        if (Input.GetKeyDown(KeyCode.Alpha3)) bulletTime.Enter(cinematicConfig);
        if (Input.GetKeyDown(KeyCode.T)) bulletTime.Toggle(standardConfig);
        if (Input.GetKeyDown(KeyCode.X)) bulletTime.Exit();
        if (Input.GetKeyDown(KeyCode.R)) RebuildDemoWorld();
    }

    private void Subscribe()
    {
        EventBus.Subscribe<BulletTimeEnterEvent>(OnBulletTimeEnter);
        EventBus.Subscribe<BulletTimeExitEvent>(OnBulletTimeExit);
        EventBus.Subscribe<BulletTimeExpiredEvent>(OnBulletTimeExpired);
        EventBus.Subscribe<BulletTimeResourceChangedEvent>(OnBulletTimeResourceChanged);
        EventBus.Subscribe<GamePausedEvent>(OnGamePaused);
        EventBus.Subscribe<GameResumedEvent>(OnGameResumed);
    }

    private void Unsubscribe()
    {
        EventBus.Unsubscribe<BulletTimeEnterEvent>(OnBulletTimeEnter);
        EventBus.Unsubscribe<BulletTimeExitEvent>(OnBulletTimeExit);
        EventBus.Unsubscribe<BulletTimeExpiredEvent>(OnBulletTimeExpired);
        EventBus.Unsubscribe<BulletTimeResourceChangedEvent>(OnBulletTimeResourceChanged);
        EventBus.Unsubscribe<GamePausedEvent>(OnGamePaused);
        EventBus.Unsubscribe<GameResumedEvent>(OnGameResumed);
    }

    private void BuildTextures()
    {
        fillTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        fillTexture.SetPixel(0, 0, new Color(0.35f, 0.85f, 1f, 1f));
        fillTexture.Apply();
    }

    private void BuildConfigs()
    {
        subtleConfig = CreateConfig("Subtle", 0.5f, 0.08f, 0.12f, 0f, 0.9f, 0.08f, 0f, 0f, 0.5f, 100f);
        standardConfig = CreateConfig("Standard", 0.3f, 0.10f, 0.18f, 3f, 0.75f, 0.10f, 10f, 18f, 12f, 100f);
        cinematicConfig = CreateConfig("Cinematic", 0.05f, 0.12f, 0.22f, 1.5f, 0.5f, 0.12f, 20f, 32f, 10f, 100f);
        resourceMax = standardConfig.MaxResource;
    }

    private SlowMoConfig_UMFOSS CreateConfig(string label, float timeScale, float enterDuration, float exitDuration, float maxDuration, float audioPitch, float audioTransition, float resourceCost, float drainRate, float rechargeRate, float maxResource)
    {
        SlowMoConfig_UMFOSS config = ScriptableObject.CreateInstance<SlowMoConfig_UMFOSS>();
        config.name = label;
        config.ApplyRuntimePreset(
            timeScale,
            enterDuration,
            exitDuration,
            maxDuration,
            AnimationCurve.EaseInOut(0f, 0f, 1f, 1f),
            AnimationCurve.EaseInOut(0f, 0f, 1f, 1f),
            audioPitch,
            audioTransition,
            resourceCost,
            drainRate,
            rechargeRate,
            maxResource);
        return config;
    }

    private void RebuildDemoWorld()
    {
        ClearScene();
        EnsureSystems();
        CreateCamera();
        CreateLights();
        CreateFloor();
        CreateMovingTarget();
        CreateRotators();
        CreateParticles();
        CreateAudio();
    }

    private void ClearScene()
    {
        GameObject[] roots = SceneManager.GetActiveScene().GetRootGameObjects();
        for (int i = 0; i < roots.Length; i++)
        {
            if (roots[i] == gameObject)
                continue;

            Destroy(roots[i]);
        }
    }

    private void EnsureSystems()
    {
        pauseSystem = GetComponent<PauseSystem_UMFOSS>();
        if (pauseSystem == null)
            pauseSystem = gameObject.AddComponent<PauseSystem_UMFOSS>();

        bulletTime = GetComponent<BulletTimeSystem_UMFOSS>();
        if (bulletTime == null)
            bulletTime = gameObject.AddComponent<BulletTimeSystem_UMFOSS>();

        bulletTime.SetDefaultConfig(standardConfig);
    }

    private void CreateCamera()
    {
        GameObject cameraGo = new GameObject("Main Camera");
        cameraGo.tag = "MainCamera";
        Camera camera = cameraGo.AddComponent<Camera>();
        camera.backgroundColor = new Color(0.06f, 0.08f, 0.12f, 1f);
        camera.clearFlags = CameraClearFlags.SolidColor;
        cameraGo.transform.position = new Vector3(0f, 7f, -16f);
        cameraGo.transform.rotation = Quaternion.Euler(20f, 0f, 0f);
        cameraGo.AddComponent<AudioListener>();
    }

    private void CreateLights()
    {
        GameObject sun = new GameObject("Directional Light");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
    }

    private void CreateFloor()
    {
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "Floor";
        floor.transform.localScale = new Vector3(2f, 1f, 2f);
        floor.GetComponent<Renderer>().material.color = new Color(0.12f, 0.13f, 0.17f);
    }

    private void CreateMovingTarget()
    {
        GameObject target = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        target.name = "Moving Target";
        target.transform.position = new Vector3(0f, 1f, 5f);
        target.transform.localScale = new Vector3(1.2f, 2.2f, 1.2f);
        target.GetComponent<Renderer>().material.color = new Color(0.95f, 0.4f, 0.35f);
        BulletTimeDemoPingPong mover = target.AddComponent<BulletTimeDemoPingPong>();
        mover.Amplitude = 5f;
        mover.Speed = 2.5f;
    }

    private void CreateRotators()
    {
        CreateSpinner(new Vector3(-5f, 1f, 0f), new Color(0.35f, 0.85f, 1f), new Vector3(0f, 160f, 0f));
        CreateSpinner(new Vector3(0f, 1f, 0f), new Color(0.4f, 1f, 0.55f), new Vector3(120f, 0f, 0f));
        CreateSpinner(new Vector3(5f, 1f, 0f), new Color(1f, 0.85f, 0.35f), new Vector3(0f, 0f, 220f));
    }

    private void CreateSpinner(Vector3 position, Color color, Vector3 speed)
    {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.position = position;
        cube.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
        cube.GetComponent<Renderer>().material.color = color;
        BulletTimeDemoSpinner spinner = cube.AddComponent<BulletTimeDemoSpinner>();
        spinner.DegreesPerSecond = speed;
    }

    private void CreateParticles()
    {
        GameObject particlesGo = new GameObject("Demo Particles");
        particlesGo.transform.position = new Vector3(0f, 1.5f, -4f);
        ParticleSystem particles = particlesGo.AddComponent<ParticleSystem>();
        var main = particles.main;
        main.startLifetime = 1.5f;
        main.startSpeed = 3f;
        main.startSize = 0.25f;
        main.startColor = new Color(0.4f, 0.8f, 1f, 1f);
        main.loop = true;
        var emission = particles.emission;
        emission.rateOverTime = 28f;
        var shape = particles.shape;
        shape.shapeType = ParticleSystemShapeType.Cone;
        shape.angle = 15f;
        particles.Play();
    }

    private void CreateAudio()
    {
        GameObject audioGo = new GameObject("Demo Audio");
        musicSource = audioGo.AddComponent<AudioSource>();
        musicSource.loop = true;
        musicSource.spatialBlend = 0f;
        musicSource.volume = 0.18f;
        musicSource.clip = BuildTone();
        musicSource.Play();
        bulletTime.RegisterFallbackAudioSource(musicSource);
    }

    private AudioClip BuildTone()
    {
        int sampleRate = 44100;
        int seconds = 2;
        int samples = sampleRate * seconds;
        AudioClip clip = AudioClip.Create("BulletTimeLoop", samples, 1, sampleRate, false);
        float[] data = new float[samples];
        for (int i = 0; i < samples; i++)
        {
            float t = i / (float)sampleRate;
            data[i] = Mathf.Sin(t * 2f * Mathf.PI * 220f) * 0.18f
                    + Mathf.Sin(t * 2f * Mathf.PI * 330f) * 0.08f
                    + Mathf.Sin(t * 2f * Mathf.PI * 440f) * 0.04f;
        }
        clip.SetData(data, 0);
        return clip;
    }

    private void OnBulletTimeEnter(BulletTimeEnterEvent e)
    {
        lastEvent = string.Format("Enter -> target {0:0.00}", e.targetTimeScale);
    }

    private void OnBulletTimeExit(BulletTimeExitEvent e)
    {
        lastEvent = string.Format("Exit -> restore {0:0.00}", e.restoredTimeScale);
    }

    private void OnBulletTimeExpired(BulletTimeExpiredEvent _)
    {
        lastEvent = "Expired";
    }

    private void OnBulletTimeResourceChanged(BulletTimeResourceChangedEvent e)
    {
        resourceMax = e.max;
        lastEvent = string.Format("Resource -> {0:0.0}%", e.percent * 100f);
    }

    private void OnGamePaused(GamePausedEvent e)
    {
        lastEvent = string.Format("Paused at {0:0.00}", e.previousTimeScale);
    }

    private void OnGameResumed(GameResumedEvent e)
    {
        lastEvent = string.Format("Resumed at {0:0.00}", e.restoredTimeScale);
    }

    private void OnGUI()
    {
        GUI.color = new Color(0f, 0f, 0f, 0.75f);
        GUI.Box(new Rect(16f, 16f, 360f, 280f), GUIContent.none);
        GUI.Box(new Rect(Screen.width - 236f, 16f, 220f, 272f), GUIContent.none);
        GUI.color = Color.white;

        GUILayout.BeginArea(new Rect(28f, 28f, 336f, 256f));
        GUILayout.Label("Bullet Time Demo", HeaderStyle());
        GUILayout.Space(6f);
        GUILayout.Label(string.Format("Time.timeScale: {0:0.000}", Time.timeScale));
        GUILayout.Label(string.Format("Time.fixedDeltaTime: {0:0.0000}", Time.fixedDeltaTime));
        GUILayout.Label(string.Format("Audio Pitch: {0:0.00}", bulletTime != null ? bulletTime.GetCurrentAudioPitch() : 1f));
        GUILayout.Label(string.Format("Is Active: {0}", bulletTime != null && bulletTime.IsActive()));
        GUILayout.Label(string.Format("Resource: {0:0.0} / {1:0.0}", bulletTime != null ? bulletTime.GetCurrentResource() : 0f, resourceMax));
        GUILayout.Label(string.Format("UI Timer (unscaled): {0:0.00}s", uiTimer));
        GUILayout.Label(string.Format("Last Event: {0}", lastEvent));
        GUILayout.Space(12f);
        GUILayout.Label("Controls: 1 Subtle | 2 Standard | 3 Cinematic | T Toggle | X Exit | Esc Pause | R Rebuild");
        GUILayout.EndArea();

        float percent = bulletTime != null ? bulletTime.GetResourcePercent() : 0f;
        GUI.Box(new Rect(28f, 220f, 320f, 24f), GUIContent.none);
        GUI.DrawTexture(new Rect(30f, 222f, 316f * percent, 20f), fillTexture);

        GUILayout.BeginArea(new Rect(Screen.width - 224f, 28f, 196f, 252f));
        GUILayout.Label("Actions", HeaderStyle());
        if (GUILayout.Button("Subtle Slow Mo")) bulletTime.Enter(subtleConfig);
        if (GUILayout.Button("Standard Slow Mo")) bulletTime.Enter(standardConfig);
        if (GUILayout.Button("Cinematic Slow Mo")) bulletTime.Enter(cinematicConfig);
        if (GUILayout.Button("Exit Slow Mo")) bulletTime.Exit();
        if (GUILayout.Button("Toggle")) bulletTime.Toggle(standardConfig);
        if (GUILayout.Button("Pause")) pauseSystem.TogglePause();
        if (GUILayout.Button("Rebuild Demo")) RebuildDemoWorld();
        GUILayout.EndArea();
    }

    private GUIStyle HeaderStyle()
    {
        GUIStyle style = new GUIStyle(GUI.skin.label);
        style.fontSize = 18;
        style.fontStyle = FontStyle.Bold;
        return style;
    }
}

public class BulletTimeDemoPingPong : MonoBehaviour
{
    public float Amplitude = 4f;
    public float Speed = 2f;
    private Vector3 startPosition;

    private void Awake()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        Vector3 pos = startPosition;
        pos.x += Mathf.Sin(Time.time * Speed) * Amplitude;
        transform.position = pos;
    }
}

public class BulletTimeDemoSpinner : MonoBehaviour
{
    public Vector3 DegreesPerSecond = new Vector3(0f, 90f, 0f);

    private void Update()
    {
        transform.Rotate(DegreesPerSecond * Time.deltaTime, Space.Self);
    }
}
