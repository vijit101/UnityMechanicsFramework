using System.Collections.Generic;
using System.IO;
using System.Net;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using GameplayMechanicsUMFOSS.Systems;
using GameplayMechanicsUMFOSS.Samples.SceneManagerSample;

namespace GameplayMechanicsUMFOSS.SamplesEditor.SceneManagerSample
{
    /// <summary>
    /// One-shot editor menu that builds the entire SLITHER snake game demo:
    /// scenes, GameObjects, components, references, transitions, build settings.
    /// Run from: Tools → UMFOSS → Generate Scene Manager Demo.
    /// </summary>
    public static class SceneManagerDemoGenerator
    {
        // ---------- Paths ----------
        private const string Root = "Assets/SceneManagerDemo";
        private const string ScenesDir = Root + "/Scenes";
        private const string TransitionsDir = Root + "/Transitions";
        private const string WhiteSquarePath = Root + "/WhiteSquare.png";
        private const string WhiteCirclePath = Root + "/WhiteCircle.png";
        private const string RoundedSquarePath = Root + "/RoundedSquare.png";
        private const string ApplePath = Root + "/Apple.png";
        private const string BombPath = Root + "/Bomb.png";
        private const string CheckerboardPath = Root + "/Checkerboard.png";
        private const string GridPath = Root + "/Grid.png";

        // Grid constants
        private const int GridX = 32;
        private const int GridY = 18;
        private const float CellSize = 0.4f;

        // ---------- Scene names ----------
        private const string Persistent = "PersistentScene";
        private const string TitleScreen = "TitleScreen";
        private const string Level_Garden = "Level_Garden";
        private const string Level_Cyber = "Level_Cyber";
        private const string Level_Void = "Level_Void";
        private const string PauseMenu = "PauseMenu";
        private const string StatsOverlay = "StatsOverlay";
        private const string SettingsOverlay = "SettingsOverlay";
        private const string GameOver = "GameOver";
        private const string Victory = "Victory";

        // ---------- Cached transition references ----------
        private static SceneTransition_UMFOSS instantTransition;
        private static SceneTransition_UMFOSS fadeBlack;
        private static SceneTransition_UMFOSS fadeWhite;
        private static SceneTransition_UMFOSS loadingBar;

        [MenuItem("Tools/UMFOSS/Generate Scene Manager Demo")]
        public static void Generate()
        {
            if (!EditorUtility.DisplayDialog(
                "Generate SLITHER Demo",
                "This will DELETE the existing Assets/SceneManagerDemo/Scenes and Transitions, then rebuild the entire snake game from scratch.\n\nProceed?",
                "Generate", "Cancel"))
                return;

            EnsureFolders();
            EnsureWhiteSquareSpriteAsset();
            EnsureWhiteCircleSpriteAsset();
            EnsureRoundedSquareSpriteAsset();
            EnsureCheckerboardSpriteAsset();
            EnsureGridSpriteAsset();
            EnsureAppleSpriteAsset();
            EnsureBombSpriteAsset();
            GenerateTransitions();

            BuildScene_Persistent();
            BuildScene_TitleScreen();
            BuildScene_Level(Level_Garden,
                titleLabel: "LEVEL 01",
                fieldColor: new Color(0.45f, 0.65f, 0.35f),
                target: 5, moveInterval: 0.11f, bombs: 0,
                bombLifeMin: 0f, bombLifeMax: 0f,
                nextScene: Level_Cyber);
            BuildScene_Level(Level_Cyber,
                titleLabel: "LEVEL 02",
                fieldColor: new Color(0.42f, 0.32f, 0.58f),
                target: 8, moveInterval: 0.085f, bombs: 1,
                bombLifeMin: 2.5f, bombLifeMax: 4.0f,
                nextScene: Level_Void);
            BuildScene_Level(Level_Void,
                titleLabel: "LEVEL 03",
                fieldColor: new Color(0.58f, 0.32f, 0.22f),
                target: 12, moveInterval: 0.065f, bombs: 3,
                bombLifeMin: 1.2f, bombLifeMax: 2.5f,
                nextScene: Victory);
            BuildScene_PauseMenu();
            BuildScene_StatsOverlay();
            BuildScene_SettingsOverlay();
            BuildScene_GameOver();
            BuildScene_Victory();

            AddToBuildSettings();

            EditorSceneManager.OpenScene(ScenesDir + "/" + Persistent + ".unity", OpenSceneMode.Single);

            EditorUtility.DisplayDialog("SLITHER Generated",
                "Snake game generated.\n\n" +
                "1. PersistentScene is open.\n" +
                "2. Press Play.\n" +
                "3. Click START at the title.\n" +
                "4. WASD/Arrows to move. Esc to pause.\n" +
                "5. Eat apples (red) — avoid bombs (dark) — don't hit the walls.",
                "OK");
        }

        // ===========================================================
        // Folder + sprite + transition setup
        // ===========================================================

        private static void EnsureFolders()
        {
            if (AssetDatabase.IsValidFolder(ScenesDir)) AssetDatabase.DeleteAsset(ScenesDir);
            if (AssetDatabase.IsValidFolder(TransitionsDir)) AssetDatabase.DeleteAsset(TransitionsDir);

            // Force regeneration of cached procedural sprites
            AssetDatabase.DeleteAsset(ApplePath);
            AssetDatabase.DeleteAsset(BombPath);
            AssetDatabase.DeleteAsset(WhiteSquarePath);
            AssetDatabase.DeleteAsset(WhiteCirclePath);
            AssetDatabase.DeleteAsset(RoundedSquarePath);
            AssetDatabase.DeleteAsset(CheckerboardPath);
            AssetDatabase.DeleteAsset(GridPath);

            if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "SceneManagerDemo");
            AssetDatabase.CreateFolder(Root, "Scenes");
            AssetDatabase.CreateFolder(Root, "Transitions");
            AssetDatabase.Refresh();
        }

        private static void GenerateTransitions()
        {
            instantTransition = ScriptableObject.CreateInstance<SceneTransition_UMFOSS>();
            instantTransition.fadeColour = Color.black;
            instantTransition.fadeOutDuration = 0f;
            instantTransition.fadeInDuration = 0f;
            AssetDatabase.CreateAsset(instantTransition, TransitionsDir + "/Instant.asset");

            fadeBlack = ScriptableObject.CreateInstance<SceneTransition_UMFOSS>();
            fadeBlack.fadeColour = Color.black;
            fadeBlack.fadeOutDuration = 0.4f;
            fadeBlack.fadeInDuration = 0.4f;
            AssetDatabase.CreateAsset(fadeBlack, TransitionsDir + "/FadeBlack.asset");

            fadeWhite = ScriptableObject.CreateInstance<SceneTransition_UMFOSS>();
            fadeWhite.fadeColour = Color.white;
            fadeWhite.fadeOutDuration = 0.5f;
            fadeWhite.fadeInDuration = 0.5f;
            AssetDatabase.CreateAsset(fadeWhite, TransitionsDir + "/FadeWhite.asset");

            loadingBar = ScriptableObject.CreateInstance<SceneTransition_UMFOSS>();
            loadingBar.fadeColour = Color.black;
            loadingBar.fadeOutDuration = 0.3f;
            loadingBar.fadeInDuration = 0.3f;
            loadingBar.showLoadingScreen = true;
            loadingBar.minimumLoadTime = 1.5f;
            AssetDatabase.CreateAsset(loadingBar, TransitionsDir + "/LoadingBar.asset");

            AssetDatabase.SaveAssets();
        }

        private static Sprite EnsureWhiteSquareSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(WhiteSquarePath);
            if (existing != null) return existing;

            var tex = new Texture2D(8, 8, TextureFormat.RGBA32, false);
            var pixels = new Color32[64];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = new Color32(255, 255, 255, 255);
            tex.SetPixels32(pixels);
            tex.Apply();

            var bytes = tex.EncodeToPNG();
            var fullPath = Path.Combine(Application.dataPath, "SceneManagerDemo/WhiteSquare.png");
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
            File.WriteAllBytes(fullPath, bytes);
            Object.DestroyImmediate(tex);

            AssetDatabase.ImportAsset(WhiteSquarePath, ImportAssetOptions.ForceSynchronousImport);

            var importer = AssetImporter.GetAtPath(WhiteSquarePath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.spritePixelsPerUnit = 8f;
                importer.filterMode = FilterMode.Point;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(WhiteSquarePath);
        }

        private static Sprite EnsureWhiteCircleSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(WhiteCirclePath);
            if (existing != null) return existing;

            const int size = 64;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            float r = (size - 1) * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x - r;
                    float dy = y - r;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - (dist - r + 1.5f));
                    if (dist > r) a = 0f;
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            tex.Apply();

            var bytes = tex.EncodeToPNG();
            var fullPath = Path.Combine(Application.dataPath, "SceneManagerDemo/WhiteCircle.png");
            File.WriteAllBytes(fullPath, bytes);
            Object.DestroyImmediate(tex);

            AssetDatabase.ImportAsset(WhiteCirclePath, ImportAssetOptions.ForceSynchronousImport);

            var importer = AssetImporter.GetAtPath(WhiteCirclePath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.spritePixelsPerUnit = 64f;
                importer.filterMode = FilterMode.Bilinear;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(WhiteCirclePath);
        }

        private static Sprite EnsureRoundedSquareSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(RoundedSquarePath);
            if (existing != null) return existing;

            const int size = 64;
            const float cornerRadius = 14f;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float a = 1f;
                    // Distance to nearest edge
                    float fx = x;
                    float fy = y;
                    float dxIn = Mathf.Min(fx, size - 1 - fx);
                    float dyIn = Mathf.Min(fy, size - 1 - fy);

                    if (dxIn < cornerRadius && dyIn < cornerRadius)
                    {
                        float dx = cornerRadius - dxIn;
                        float dy = cornerRadius - dyIn;
                        float dist = Mathf.Sqrt(dx * dx + dy * dy);
                        a = Mathf.Clamp01(cornerRadius - dist + 0.5f);
                    }
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            tex.Apply();

            var bytes = tex.EncodeToPNG();
            var fullPath = Path.Combine(Application.dataPath, "SceneManagerDemo/RoundedSquare.png");
            File.WriteAllBytes(fullPath, bytes);
            Object.DestroyImmediate(tex);

            AssetDatabase.ImportAsset(RoundedSquarePath, ImportAssetOptions.ForceSynchronousImport);

            var importer = AssetImporter.GetAtPath(RoundedSquarePath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.spritePixelsPerUnit = 64f;
                importer.filterMode = FilterMode.Bilinear;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(RoundedSquarePath);
        }

        private static Sprite SquareSprite => AssetDatabase.LoadAssetAtPath<Sprite>(WhiteSquarePath);
        private static Sprite CircleSprite => AssetDatabase.LoadAssetAtPath<Sprite>(WhiteCirclePath);
        private static Sprite RoundedSquareSprite => AssetDatabase.LoadAssetAtPath<Sprite>(RoundedSquarePath);
        private static Sprite AppleSprite => AssetDatabase.LoadAssetAtPath<Sprite>(ApplePath);
        private static Sprite BombSprite => AssetDatabase.LoadAssetAtPath<Sprite>(BombPath);
        private static Sprite CheckerboardSprite => AssetDatabase.LoadAssetAtPath<Sprite>(CheckerboardPath);
        private static Sprite GridSprite => AssetDatabase.LoadAssetAtPath<Sprite>(GridPath);

        // ===========================================================
        // Grid texture — visible cell lines, point-filtered, tinted per level
        // ===========================================================

        private static Sprite EnsureGridSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(GridPath);
            if (existing != null) return existing;

            const int cellPx = 24;
            int W = GridX * cellPx, H = GridY * cellPx;
            var tex = new Texture2D(W, H, TextureFormat.RGBA32, false);

            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    int cx = x % cellPx;
                    int cy = y % cellPx;
                    // 1 px line on the top + left edge of each cell
                    bool line = (cx == 0) || (cy == 0);
                    var c = line ? new Color(0.78f, 0.78f, 0.78f) : Color.white;
                    tex.SetPixel(x, y, c);
                }
            }
            tex.Apply();

            // pixelsPerUnit so 1 cell (24 px) = CellSize world units
            SavePngAndImport(tex, GridPath, "SceneManagerDemo/Grid.png", cellPx / CellSize);
            Object.DestroyImmediate(tex);

            var importer = AssetImporter.GetAtPath(GridPath) as TextureImporter;
            if (importer != null)
            {
                importer.filterMode = FilterMode.Point;
                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(GridPath);
        }

        // ===========================================================
        // Twemoji download with procedural fallback
        // ===========================================================

        /// <summary>
        /// Tries downloading a high-quality emoji PNG from multiple sources in priority order:
        /// OpenMoji (618x618 → 72x72) → Twemoji (72x72). Returns true on first success.
        /// </summary>
        private static bool DownloadEmojiPNG(string upperCp, string lowerCp, string fullPath)
        {
            string[] urls = new[] {
                $"https://cdn.jsdelivr.net/gh/hfg-gmuend/openmoji@latest/color/618x618/{upperCp}.png",
                $"https://cdn.jsdelivr.net/gh/hfg-gmuend/openmoji@latest/color/72x72/{upperCp}.png",
                $"https://raw.githubusercontent.com/hfg-gmuend/openmoji/master/color/618x618/{upperCp}.png",
                $"https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/72x72/{lowerCp}.png",
                $"https://raw.githubusercontent.com/twitter/twemoji/master/assets/72x72/{lowerCp}.png",
            };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            foreach (var url in urls)
            {
                try
                {
                    using (var client = new WebClient())
                    {
                        client.Headers.Add("User-Agent", "UnityEditor/1.0");
                        var bytes = client.DownloadData(url);
                        if (bytes != null && bytes.Length > 1000)
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
                            File.WriteAllBytes(fullPath, bytes);
                            Debug.Log($"[SceneManagerDemoGenerator] Downloaded {url} ({bytes.Length} bytes)");
                            return true;
                        }
                    }
                }
                catch (System.Exception e)
                {
                    Debug.Log($"[SceneManagerDemoGenerator] Fetch '{url}' failed: {e.Message}");
                }
            }
            return false;
        }

        /// <summary>
        /// Imports a downloaded emoji PNG as a Sprite, sized so that its natural world
        /// size = CellSize * 1.20 (i.e. the fruit/bomb visually overflows the cell slightly
        /// and becomes a prominent target).
        /// </summary>
        private static void ImportEmojiAsCellSizedSprite(string assetPath, string fullDiskPath)
        {
            // Read PNG dimensions to compute the right pixelsPerUnit
            var bytes = File.ReadAllBytes(fullDiskPath);
            var temp = new Texture2D(2, 2);
            temp.LoadImage(bytes);
            int h = temp.height;
            Object.DestroyImmediate(temp);

            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport);
            var imp = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (imp != null)
            {
                imp.textureType = TextureImporterType.Sprite;
                imp.spriteImportMode = SpriteImportMode.Single;
                // Sprite natural world size = CellSize * 1.20 → fruit ~20% bigger than a cell
                imp.spritePixelsPerUnit = h / (CellSize * 1.20f);
                imp.filterMode = FilterMode.Bilinear;
                imp.mipmapEnabled = true; // helps with downscaling clean look
                imp.alphaIsTransparency = true;
                imp.SaveAndReimport();
            }
        }

        // ===========================================================
        // Checkerboard background (greyscale, tinted per-level)
        // ===========================================================

        private static Sprite EnsureCheckerboardSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(CheckerboardPath);
            if (existing != null) return existing;

            // 24x14 grid, each cell 32 px → 768x448 texture
            const int gx = 24, gy = 14, cellPx = 32;
            int W = gx * cellPx, H = gy * cellPx;
            var tex = new Texture2D(W, H, TextureFormat.RGBA32, false);

            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    int cx = x / cellPx;
                    int cy = y / cellPx;
                    bool light = ((cx + cy) & 1) == 0;
                    // Greyscale, tinted later via SpriteRenderer.color
                    var c = light ? new Color(1f, 1f, 1f) : new Color(0.86f, 0.86f, 0.86f);
                    tex.SetPixel(x, y, c);
                }
            }
            tex.Apply();

            SavePngAndImport(tex, CheckerboardPath, "SceneManagerDemo/Checkerboard.png", cellPx / 0.6f); // 32 px = 0.6 units
            Object.DestroyImmediate(tex);

            // Switch the importer to point filter for crisp pixel edges
            var importer = AssetImporter.GetAtPath(CheckerboardPath) as TextureImporter;
            if (importer != null)
            {
                importer.filterMode = FilterMode.Point;
                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(CheckerboardPath);
        }

        // ===========================================================
        // Strawberry — downloaded from OpenMoji/Twemoji emoji library (1F353)
        // ===========================================================

        private static Sprite EnsureAppleSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(ApplePath);
            if (existing != null) return existing;

            var fullPath = Path.Combine(Application.dataPath, "SceneManagerDemo/Apple.png");
            if (DownloadEmojiPNG("1F353", "1f353", fullPath))
            {
                ImportEmojiAsCellSizedSprite(ApplePath, fullPath);
                return AssetDatabase.LoadAssetAtPath<Sprite>(ApplePath);
            }

            Debug.LogWarning("[SceneManagerDemoGenerator] Strawberry download failed — falling back to white square.");
            return SquareSprite;
        }

        // ===========================================================
        // Bomb — downloaded from OpenMoji/Twemoji emoji library (1F4A3)
        // ===========================================================

        private static Sprite EnsureBombSpriteAsset()
        {
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(BombPath);
            if (existing != null) return existing;

            var fullPath = Path.Combine(Application.dataPath, "SceneManagerDemo/Bomb.png");
            if (DownloadEmojiPNG("1F4A3", "1f4a3", fullPath))
            {
                ImportEmojiAsCellSizedSprite(BombPath, fullPath);
                return AssetDatabase.LoadAssetAtPath<Sprite>(BombPath);
            }

            Debug.LogWarning("[SceneManagerDemoGenerator] Bomb download failed — falling back to white square.");
            return SquareSprite;
        }

        // ===========================================================
        // Texture drawing helpers
        // ===========================================================

        private static void DrawSoftCircle(Texture2D tex, int cx, int cy, float r, Color color)
        {
            int rInt = Mathf.CeilToInt(r);
            for (int dy = -rInt; dy <= rInt; dy++)
            {
                for (int dx = -rInt; dx <= rInt; dx++)
                {
                    int x = cx + dx, y = cy + dy;
                    if (x < 0 || y < 0 || x >= tex.width || y >= tex.height) continue;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    if (dist > r) continue;
                    float falloff = Mathf.Clamp01(1f - dist / r);
                    var c = color; c.a *= falloff;
                    var existing = tex.GetPixel(x, y);
                    var blended = Color.Lerp(existing, c, c.a);
                    blended.a = Mathf.Max(existing.a, c.a);
                    tex.SetPixel(x, y, blended);
                }
            }
        }

        private static void FillRect(Texture2D tex, int x0, int y0, int x1, int y1, Color color)
        {
            for (int y = y0; y <= y1; y++)
                for (int x = x0; x <= x1; x++)
                    if (x >= 0 && y >= 0 && x < tex.width && y < tex.height)
                        tex.SetPixel(x, y, color);
        }

        private static void DrawAngledEllipse(Texture2D tex, int cx, int cy, float rx, float ry, float angleDeg, Color edge, Color center)
        {
            float ang = angleDeg * Mathf.Deg2Rad;
            float ca = Mathf.Cos(ang), sa = Mathf.Sin(ang);
            int rMax = Mathf.CeilToInt(Mathf.Max(rx, ry) + 2);
            for (int dy = -rMax; dy <= rMax; dy++)
            {
                for (int dx = -rMax; dx <= rMax; dx++)
                {
                    int x = cx + dx, y = cy + dy;
                    if (x < 0 || y < 0 || x >= tex.width || y >= tex.height) continue;
                    float lx = dx * ca + dy * sa;
                    float ly = -dx * sa + dy * ca;
                    float d = Mathf.Sqrt((lx / rx) * (lx / rx) + (ly / ry) * (ly / ry));
                    if (d > 1f) continue;
                    float aa = Mathf.Clamp01((1f - d) * 8f);
                    Color c = Color.Lerp(center, edge, d);
                    c.a = aa;
                    var existing = tex.GetPixel(x, y);
                    var blended = Color.Lerp(existing, c, c.a);
                    blended.a = Mathf.Max(existing.a, c.a);
                    tex.SetPixel(x, y, blended);
                }
            }
        }

        private static void DrawLine(Texture2D tex, int x0, int y0, int x1, int y1, Color color)
        {
            int dx = Mathf.Abs(x1 - x0), dy = Mathf.Abs(y1 - y0);
            int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
            int err = dx - dy;
            while (true)
            {
                if (x0 >= 0 && y0 >= 0 && x0 < tex.width && y0 < tex.height)
                    tex.SetPixel(x0, y0, color);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 > -dy) { err -= dy; x0 += sx; }
                if (e2 < dx) { err += dx; y0 += sy; }
            }
        }

        private static void SavePngAndImport(Texture2D tex, string assetPath, string relativePath, float pixelsPerUnit)
        {
            var bytes = tex.EncodeToPNG();
            var fullPath = Path.Combine(Application.dataPath, relativePath);
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
            File.WriteAllBytes(fullPath, bytes);
            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport);
            var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.spritePixelsPerUnit = pixelsPerUnit;
                importer.filterMode = FilterMode.Bilinear;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }
        }

        // ===========================================================
        // Scene: Persistent
        // ===========================================================

        private static void BuildScene_Persistent()
        {
            var scene = NewScene(Persistent);

            // _Bootstrap with SceneManager + PersistentScene marker
            var bootstrap = new GameObject("_Bootstrap");
            bootstrap.AddComponent<PersistentScene_UMFOSS>();
            var sm = bootstrap.AddComponent<SceneManager_UMFOSS>();
            SetPrivateField(sm, "persistentSceneName", Persistent);
            SetPrivateField(sm, "defaultTransition", fadeBlack);

            // Game stats singleton
            var statsGO = new GameObject("GameStats");
            statsGO.AddComponent<GameStats>();

            // Game over watcher
            var watcherGO = new GameObject("GameOverWatcher");
            var watcher = watcherGO.AddComponent<GameOverWatcher>();
            SetPrivateField(watcher, "gameOverScene", GameOver);
            SetPrivateField(watcher, "transition", fadeBlack);

            // Initial scene loader
            var loaderGO = new GameObject("InitialSceneLoader");
            var loader = loaderGO.AddComponent<InitialSceneLoader>();
            SetPrivateField(loader, "initialScene", TitleScreen);
            SetPrivateField(loader, "transition", instantTransition);

            // Persistent gameplay HUD canvas
            var hudCanvas = CreateCanvas("PersistentHUD", 9000);
            var hudRoot = new GameObject("HUDRoot");
            hudRoot.transform.SetParent(hudCanvas.transform, false);
            var hudRT = hudRoot.AddComponent<RectTransform>();
            StretchFull(hudRT);

            // Minimal HUD — three top labels + bottom stats line. NO cards, NO backgrounds.
            var levelLabel = CreateLabel(hudRoot.transform, "LevelLabel", "",
                TextAnchor.UpperLeft, 60, -50, 700, 60, 36, Color.white);
            levelLabel.alignment = TextAlignmentOptions.Left;

            var scoreLabel = CreateLabel(hudRoot.transform, "ScoreLabel", "",
                TextAnchor.UpperCenter, 0, -45, 800, 80, 64, Color.white);
            scoreLabel.fontStyle = FontStyles.Bold;

            var pauseHint = CreateLabel(hudRoot.transform, "PauseHint", "",
                TextAnchor.UpperRight, -60, -55, 700, 50, 28, Color.white);
            pauseHint.alignment = TextAlignmentOptions.Right;

            var statsLine = CreateLabel(hudRoot.transform, "StatsLine", "",
                TextAnchor.LowerLeft, 60, 30, 1500, 40, 22, Color.white);
            statsLine.alignment = TextAlignmentOptions.Left;

            // Bottom-right: Event log — small, no background, semi-transparent
            CreateLabel(hudRoot.transform, "EventLogTitle", "<color=#9CE5FF80>EVENT BUS</color>",
                TextAnchor.LowerRight, -60, 200, 500, 28, 18);
            var eventText = CreateLabel(hudRoot.transform, "EventLogText", "",
                TextAnchor.LowerRight, -60, 50, 600, 150, 18, new Color(1f, 1f, 1f, 0.85f));
            eventText.alignment = TextAlignmentOptions.BottomRight;
            eventText.enableWordWrapping = false;
            eventText.overflowMode = TextOverflowModes.Overflow;

            var eventLogGO = new GameObject("EventLogPanel");
            var eventLog = eventLogGO.AddComponent<EventLogPanel>();
            SetPrivateField(eventLog, "text", eventText);

            // Loading screen overlay (initially hidden)
            var loadCanvas = CreateCanvas("LoadingScreenCanvas", 9500);
            var loadPanel = CreatePanel(loadCanvas.transform, "LoadingPanel", new Color(0.02f, 0.02f, 0.06f, 1f));
            StretchFull(loadPanel.GetComponent<RectTransform>());

            CreateLabel(loadPanel.transform, "LoadingTitle", "LOADING",
                TextAnchor.MiddleCenter, 0, 80, 1200, 110, 80, new Color(0.4f, 0.95f, 1f));

            // Slider
            var sliderGO = new GameObject("LoadSlider");
            sliderGO.transform.SetParent(loadPanel.transform, false);
            var sliderRT = sliderGO.AddComponent<RectTransform>();
            ApplyAnchor(sliderRT, TextAnchor.MiddleCenter);
            sliderRT.sizeDelta = new Vector2(900, 28);
            sliderRT.anchoredPosition = new Vector2(0, -40);
            var slider = sliderGO.AddComponent<Slider>();

            var sliderBg = CreatePanel(sliderGO.transform, "Background", new Color(0.10f, 0.10f, 0.18f));
            StretchFull(sliderBg.GetComponent<RectTransform>());

            var fillAreaGO = new GameObject("Fill Area");
            fillAreaGO.transform.SetParent(sliderGO.transform, false);
            var fillAreaRT = fillAreaGO.AddComponent<RectTransform>();
            fillAreaRT.anchorMin = new Vector2(0, 0);
            fillAreaRT.anchorMax = new Vector2(1, 1);
            fillAreaRT.offsetMin = new Vector2(4, 4);
            fillAreaRT.offsetMax = new Vector2(-4, -4);

            var fillGO = CreatePanel(fillAreaGO.transform, "Fill", new Color(0.4f, 0.95f, 1f));
            var fillRT = fillGO.GetComponent<RectTransform>();
            fillRT.anchorMin = new Vector2(0, 0);
            fillRT.anchorMax = new Vector2(1, 1);
            fillRT.offsetMin = Vector2.zero;
            fillRT.offsetMax = Vector2.zero;

            slider.targetGraphic = sliderBg.GetComponent<Image>();
            slider.fillRect = fillRT;
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.value = 0f;
            slider.interactable = false;

            var tipText = CreateLabel(loadPanel.transform, "TipText", "Loading...",
                TextAnchor.MiddleCenter, 0, -110, 1500, 60, 28, new Color(0.85f, 0.85f, 1f));

            var loadingScript = loadPanel.AddComponent<LoadingScreen_UMFOSS>();
            SetPrivateField(loadingScript, "panel", loadPanel);
            SetPrivateField(loadingScript, "progressBar", slider);
            SetPrivateField(loadingScript, "tipText", tipText);
            SetPrivateStringArray(loadingScript, "loadingTips", new[] {
                "Tip: bombs grow more frequent each level.",
                "Tip: you cannot reverse direction directly into yourself.",
                "Scene Manager — async load with no main-thread freeze.",
                "WaitForSecondsRealtime keeps fades alive while paused.",
                "allowSceneActivation = false prevents half-loaded flashes.",
                "Push for overlays. Pop to return. LoadScene clears the stack.",
                "The persistent scene is what carries your stats between levels.",
            });

            loadPanel.SetActive(false);
            SetPrivateField(sm, "loadingScreen", loadingScript);

            // Screen flash overlay
            var flashCanvas = CreateCanvas("FlashCanvas", 9800);
            var flashImage = CreatePanel(flashCanvas.transform, "FlashImage", new Color(1f, 1f, 1f, 0f));
            StretchFull(flashImage.GetComponent<RectTransform>());
            flashImage.GetComponent<Image>().raycastTarget = false;

            var flashGO = new GameObject("CameraScreenFlash");
            var flash = flashGO.AddComponent<CameraScreenFlash>();
            SetPrivateField(flash, "flashImage", flashImage.GetComponent<Image>());

            // SnakeHUD controller
            var hudCtrlGO = new GameObject("SnakeHUD");
            var hud = hudCtrlGO.AddComponent<SnakeHUD>();
            SetPrivateField(hud, "scoreLabel", scoreLabel);
            SetPrivateField(hud, "levelLabel", levelLabel);
            SetPrivateField(hud, "pauseHintLabel", pauseHint);
            SetPrivateField(hud, "statsLine", statsLine);
            SetPrivateField(hud, "root", hudRoot);

            // EventSystem
            var es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

            SaveScene(scene, Persistent);
        }

        // (CreateStatCard removed — HUD now uses plain text labels with no card backgrounds)

        // ===========================================================
        // Scene: Title
        // ===========================================================

        private static void BuildScene_TitleScreen()
        {
            var scene = NewScene(TitleScreen);

            // Solid dark camera background — minimal, no clutter
            CreateCamera("Main Camera", new Color(0.06f, 0.10f, 0.08f));

            var canvas = CreateCanvas("TitleCanvas", 0);

            // Big bold title
            var title = CreateLabel(canvas.transform, "Title", "SLITHER", TextAnchor.MiddleCenter, 0, 220, 1600, 280, 240, Color.white);
            title.fontStyle = FontStyles.Bold;

            // Tagline
            CreateLabel(canvas.transform, "Tagline", "a scene manager demo", TextAnchor.MiddleCenter, 0, 70, 1600, 60, 30, new Color(0.55f, 0.85f, 0.65f));

            // Thin divider line
            var line = new GameObject("DivLine");
            line.transform.SetParent(canvas.transform, false);
            var lineImg = line.AddComponent<Image>();
            lineImg.sprite = SquareSprite;
            lineImg.color = new Color(0.55f, 0.85f, 0.65f, 0.6f);
            lineImg.raycastTarget = false;
            var lineRT = lineImg.rectTransform;
            ApplyAnchor(lineRT, TextAnchor.MiddleCenter);
            lineRT.sizeDelta = new Vector2(360, 2);
            lineRT.anchoredPosition = new Vector2(0, 30);

            // Small hint
            var pressStart = CreateLabel(canvas.transform, "PressStart", "arrow keys or WASD to slither", TextAnchor.MiddleCenter, 0, -10, 1600, 40, 22, new Color(1f, 1f, 1f, 0.4f));

            // Buttons
            var startBtn = CreateThemedButton(canvas.transform, "StartButton", "START GAME", 0, -110, 460, 80, new Color(0.45f, 0.85f, 0.50f));
            var settingsBtn = CreateThemedButton(canvas.transform, "SettingsButton", "SETTINGS", 0, -210, 460, 80, new Color(0.55f, 0.75f, 0.90f));
            var quitBtn = CreateThemedButton(canvas.transform, "QuitButton", "QUIT", 0, -310, 460, 80, new Color(0.55f, 0.55f, 0.60f));

            var ctrlGO = new GameObject("TitleScreenController");
            var ctrl = ctrlGO.AddComponent<TitleScreenController>();
            SetPrivateField(ctrl, "titleText", title);
            SetPrivateField(ctrl, "subtitleText", pressStart);
            SetPrivateField(ctrl, "startButton", startBtn);
            SetPrivateField(ctrl, "settingsButton", settingsBtn);
            SetPrivateField(ctrl, "quitButton", quitBtn);
            SetPrivateField(ctrl, "nextScene", Level_Garden);
            SetPrivateField(ctrl, "settingsOverlay", SettingsOverlay);
            SetPrivateField(ctrl, "loadingTransition", loadingBar);
            SetPrivateField(ctrl, "instantTransition", instantTransition);

            SaveScene(scene, TitleScreen);
        }

        // ===========================================================
        // Scene: Level (parameterized)
        // ===========================================================

        private static void BuildScene_Level(string sceneName, string titleLabel, Color fieldColor, int target, float moveInterval, int bombs, float bombLifeMin, float bombLifeMax, string nextScene)
        {
            var scene = NewScene(sceneName);

            // Darker camera background — outside the play field
            CreateCamera("Main Camera", new Color(fieldColor.r * 0.18f, fieldColor.g * 0.18f, fieldColor.b * 0.20f));

            // Stage title (UI canvas)
            var canvas = CreateCanvas("StageCanvas", 0);
            CreateLabel(canvas.transform, "StageTitle", titleLabel, TextAnchor.LowerCenter, 0, 30, 1600, 60, 28, new Color(1f, 1f, 1f, 0.45f));

            // Grid arena
            var arena = new GameObject("GridArena");
            var arenaScript = arena.AddComponent<GridArena>();
            SetPrivateField(arenaScript, "gridSize", new Vector2Int(GridX, GridY));
            SetPrivateField(arenaScript, "cellSize", CellSize);

            // Exact play field dimensions (matches grid logic)
            float halfW = GridX * CellSize * 0.5f;
            float halfH = GridY * CellSize * 0.5f;

            // ----- Play field — grid texture tinted with the level color -----
            var board = new GameObject("PlayField");
            board.transform.position = new Vector3(0, 0, 5f);
            // Sprite native size = (GridX * 24 / pixelsPerUnit) x (GridY * 24 / pixelsPerUnit)
            //                    = GridX * CellSize x GridY * CellSize → exact play field size
            board.transform.localScale = Vector3.one;
            var boardSR = board.AddComponent<SpriteRenderer>();
            boardSR.sprite = GridSprite;
            boardSR.color = fieldColor;
            boardSR.sortingOrder = -100;

            // ----- Single uniform pixel border, perfectly aligned to play field edge -----
            const float pixelSize = 0.16f;
            Color pixelColor = Color.Lerp(fieldColor, Color.black, 0.70f);

            int countX = Mathf.RoundToInt((halfW * 2) / pixelSize);
            int countY = Mathf.RoundToInt((halfH * 2) / pixelSize);

            // Top & bottom rows (full width including corners)
            for (int i = 0; i <= countX; i++)
            {
                float fx = -halfW + i * pixelSize;
                CreatePixelBorder(new Vector3(fx,  halfH + pixelSize * 0.5f, 0), pixelSize, pixelColor);
                CreatePixelBorder(new Vector3(fx, -halfH - pixelSize * 0.5f, 0), pixelSize, pixelColor);
            }
            // Left & right cols (no corner overlap)
            for (int i = 0; i <= countY; i++)
            {
                float fy = -halfH + i * pixelSize;
                CreatePixelBorder(new Vector3(-halfW - pixelSize * 0.5f, fy, 0), pixelSize, pixelColor);
                CreatePixelBorder(new Vector3( halfW + pixelSize * 0.5f, fy, 0), pixelSize, pixelColor);
            }

            // Snake — uniform rounded squares with high overlap so turns stay
            // visually connected through the diagonal moment
            var snakeGO = new GameObject("Snake");
            var snake = snakeGO.AddComponent<Snake>();
            SetPrivateField(snake, "segmentSprite", RoundedSquareSprite);
            SetPrivateField(snake, "circleSprite", CircleSprite);
            SetPrivateField(snake, "tongueSprite", SquareSprite);
            SetPrivateField(snake, "moveInterval", moveInterval);
            SetPrivateField(snake, "cellSize", CellSize);
            SetPrivateField(snake, "gridSize", new Vector2Int(GridX, GridY));
            SetPrivateField(snake, "bodyScaleMul", 1.22f);
            SetPrivateField(snake, "pauseSceneName", PauseMenu);

            // Single uniform color for the whole snake
            var snakeColor = Color.Lerp(fieldColor, Color.black, 0.78f);
            SetPrivateField(snake, "headColor", snakeColor);
            SetPrivateField(snake, "tailColor", snakeColor);

            // Food spawner
            var spawnerGO = new GameObject("FoodSpawner");
            var spawner = spawnerGO.AddComponent<FoodSpawner>();
            SetSpawnerCounts(spawner, 1, bombs, bombLifeMin, bombLifeMax);
            spawnerGO.AddComponent<FoodFactoryBootstrap>();

            // Level goal
            var goalGO = new GameObject("LevelGoal");
            var goal = goalGO.AddComponent<LevelGoal>();
            SetPrivateField(goal, "levelName", sceneName);
            SetPrivateField(goal, "appleTarget", target);
            SetPrivateField(goal, "nextScene", nextScene);
            SetPrivateField(goal, "transition", loadingBar);

            SaveScene(scene, sceneName);
        }

        private static void SetSpawnerCounts(FoodSpawner spawner, int apples, int bombs, float bombLifeMin, float bombLifeMax)
        {
            var so = new SerializedObject(spawner);
            so.FindProperty("desiredApples").intValue = apples;
            so.FindProperty("desiredBombs").intValue = bombs;
            so.FindProperty("bombLifetimeMin").floatValue = bombLifeMin;
            so.FindProperty("bombLifetimeMax").floatValue = bombLifeMax;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void CreatePixelBorder(Vector3 pos, float size, Color color)
        {
            var go = new GameObject("BorderPx");
            go.transform.position = pos;
            go.transform.localScale = new Vector3(size, size, 1f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = SquareSprite;
            sr.color = color;
            sr.sortingOrder = 6;
        }

        // ===========================================================
        // Scene: PauseMenu
        // ===========================================================

        private static void BuildScene_PauseMenu()
        {
            var scene = NewScene(PauseMenu);

            var camGO = new GameObject("Main Camera");
            var cam = camGO.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.Nothing;
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.depth = 1;
            camGO.tag = "MainCamera";
            camGO.transform.position = new Vector3(0, 0, -10);

            var canvas = CreateCanvas("PauseCanvas", 100);

            var dim = CreatePanel(canvas.transform, "Dim", new Color(0f, 0f, 0f, 0.7f));
            StretchFull(dim.GetComponent<RectTransform>());

            CreateLabel(canvas.transform, "Title", "PAUSED", TextAnchor.MiddleCenter, 0, 220, 800, 140, 110, new Color(0.5f, 1f, 0.55f));
            CreateLabel(canvas.transform, "Subtitle", ">>  GAME HALTED  <<", TextAnchor.MiddleCenter, 0, 130, 800, 70, 30, new Color(0.4f, 0.9f, 1f));

            var resumeBtn = CreateThemedButton(canvas.transform, "ResumeButton", "RESUME", 0, 20, 400, 80, new Color(0.5f, 1f, 0.55f));
            var statsBtn = CreateThemedButton(canvas.transform, "StatsButton", "STATS", 0, -80, 400, 80, new Color(1f, 0.85f, 0.4f));
            var restartBtn = CreateThemedButton(canvas.transform, "RestartButton", "RESTART LEVEL", 0, -180, 400, 80, new Color(0.85f, 0.4f, 1f));
            var titleBtn = CreateThemedButton(canvas.transform, "TitleButton", "QUIT TO TITLE", 0, -280, 400, 80, new Color(0.6f, 0.6f, 0.7f));

            var ctrlGO = new GameObject("PauseMenuController");
            var ctrl = ctrlGO.AddComponent<PauseMenuController>();
            SetPrivateField(ctrl, "resumeButton", resumeBtn);
            SetPrivateField(ctrl, "statsButton", statsBtn);
            SetPrivateField(ctrl, "restartButton", restartBtn);
            SetPrivateField(ctrl, "titleButton", titleBtn);
            SetPrivateField(ctrl, "statsOverlay", StatsOverlay);
            SetPrivateField(ctrl, "titleScene", TitleScreen);
            SetPrivateField(ctrl, "instantTransition", instantTransition);
            SetPrivateField(ctrl, "fadeTransition", fadeBlack);

            SaveScene(scene, PauseMenu);
        }

        // ===========================================================
        // Scene: StatsOverlay
        // ===========================================================

        private static void BuildScene_StatsOverlay()
        {
            var scene = NewScene(StatsOverlay);

            var camGO = new GameObject("Main Camera");
            var cam = camGO.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.Nothing;
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.depth = 2;
            camGO.tag = "MainCamera";
            camGO.transform.position = new Vector3(0, 0, -10);

            var canvas = CreateCanvas("StatsCanvas", 200);

            var dim = CreatePanel(canvas.transform, "Dim", new Color(0.05f, 0.02f, 0.08f, 0.85f));
            StretchFull(dim.GetComponent<RectTransform>());

            var panelBg = CreatePanel(canvas.transform, "StatsPanel", new Color(0.08f, 0.10f, 0.18f, 0.95f));
            ApplyAnchor(panelBg.GetComponent<RectTransform>(), TextAnchor.MiddleCenter);
            panelBg.GetComponent<RectTransform>().sizeDelta = new Vector2(900, 600);

            CreateLabel(panelBg.transform, "Title", "STATS", TextAnchor.UpperCenter, 0, -40, 800, 80, 80, new Color(1f, 0.85f, 0.4f));
            CreateLabel(panelBg.transform, "Subtitle", "your run so far", TextAnchor.UpperCenter, 0, -120, 800, 40, 24, new Color(0.4f, 0.9f, 1f, 0.7f));

            var applesText = CreateLabel(panelBg.transform, "ApplesText", "", TextAnchor.MiddleCenter, 0, 60, 800, 50, 36);
            var levelsText = CreateLabel(panelBg.transform, "LevelsText", "", TextAnchor.MiddleCenter, 0, 0, 800, 50, 36);
            var scoreText = CreateLabel(panelBg.transform, "ScoreText", "", TextAnchor.MiddleCenter, 0, -60, 800, 50, 36);

            var closeBtn = CreateThemedButton(panelBg.transform, "CloseButton", "CLOSE", 0, -210, 350, 80, new Color(0.6f, 0.6f, 0.7f));

            var ctrlGO = new GameObject("StatsOverlayController");
            var ctrl = ctrlGO.AddComponent<StatsOverlayController>();
            SetPrivateField(ctrl, "closeButton", closeBtn);
            SetPrivateField(ctrl, "applesText", applesText);
            SetPrivateField(ctrl, "levelsText", levelsText);
            SetPrivateField(ctrl, "scoreText", scoreText);
            SetPrivateField(ctrl, "instantTransition", instantTransition);

            SaveScene(scene, StatsOverlay);
        }

        // ===========================================================
        // Scene: SettingsOverlay
        // ===========================================================

        private static void BuildScene_SettingsOverlay()
        {
            var scene = NewScene(SettingsOverlay);

            var camGO = new GameObject("Main Camera");
            var cam = camGO.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.Nothing;
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.depth = 2;
            camGO.tag = "MainCamera";
            camGO.transform.position = new Vector3(0, 0, -10);

            var canvas = CreateCanvas("SettingsCanvas", 200);

            var dim = CreatePanel(canvas.transform, "Dim", new Color(0.05f, 0.05f, 0.10f, 0.85f));
            StretchFull(dim.GetComponent<RectTransform>());

            var panelBg = CreatePanel(canvas.transform, "SettingsPanel", new Color(0.08f, 0.08f, 0.18f, 0.95f));
            ApplyAnchor(panelBg.GetComponent<RectTransform>(), TextAnchor.MiddleCenter);
            panelBg.GetComponent<RectTransform>().sizeDelta = new Vector2(800, 500);

            CreateLabel(panelBg.transform, "Title", "SETTINGS", TextAnchor.UpperCenter, 0, -40, 800, 80, 64, new Color(0.4f, 0.9f, 1f));
            CreateLabel(panelBg.transform, "Subtitle", "options menu", TextAnchor.UpperCenter, 0, -110, 800, 40, 24, new Color(1f, 1f, 1f, 0.5f));

            CreateLabel(panelBg.transform, "Stub", "(this overlay exists purely\nto prove Push works from the title)",
                TextAnchor.MiddleCenter, 0, 30, 700, 120, 26, new Color(1f, 1f, 1f, 0.7f));

            var closeBtn = CreateThemedButton(panelBg.transform, "CloseButton", "CLOSE", 0, -180, 350, 80, new Color(0.6f, 0.6f, 0.7f));

            var ctrlGO = new GameObject("SettingsOverlayController");
            var ctrl = ctrlGO.AddComponent<SettingsOverlayController>();
            SetPrivateField(ctrl, "closeButton", closeBtn);
            SetPrivateField(ctrl, "instantTransition", instantTransition);

            SaveScene(scene, SettingsOverlay);
        }

        // ===========================================================
        // Scene: GameOver
        // ===========================================================

        private static void BuildScene_GameOver()
        {
            var scene = NewScene(GameOver);

            CreateCamera("Main Camera", new Color(0.08f, 0.04f, 0.06f));

            var canvas = CreateCanvas("GameOverCanvas", 0);

            CreateLabel(canvas.transform, "Title", "GAME OVER", TextAnchor.MiddleCenter, 0, 200, 1600, 220, 120, new Color(1f, 0.30f, 0.35f));
            CreateLabel(canvas.transform, "Subtitle", "the snake has fallen", TextAnchor.MiddleCenter, 0, 100, 1400, 60, 28, new Color(1f, 0.7f, 0.7f, 0.7f));

            // Thin red divider
            var line = new GameObject("DivLine");
            line.transform.SetParent(canvas.transform, false);
            var lineImg = line.AddComponent<Image>();
            lineImg.sprite = SquareSprite;
            lineImg.color = new Color(1f, 0.30f, 0.35f, 0.4f);
            lineImg.raycastTarget = false;
            var lineRT = lineImg.rectTransform;
            ApplyAnchor(lineRT, TextAnchor.MiddleCenter);
            lineRT.sizeDelta = new Vector2(420, 2);
            lineRT.anchoredPosition = new Vector2(0, 60);

            var statsText = CreateLabel(canvas.transform, "StatsText", "",
                TextAnchor.MiddleCenter, 0, -10, 1200, 140, 28, new Color(1f, 1f, 1f, 0.85f));

            var retryBtn = CreateThemedButton(canvas.transform, "RetryButton", "RETRY", 0, -180, 460, 90, new Color(1f, 0.4f, 0.5f));
            var titleBtn = CreateThemedButton(canvas.transform, "TitleButton", "QUIT TO TITLE", 0, -290, 460, 90, new Color(0.55f, 0.55f, 0.62f));

            var ctrlGO = new GameObject("GameOverController");
            var ctrl = ctrlGO.AddComponent<GameOverController>();
            SetPrivateField(ctrl, "retryButton", retryBtn);
            SetPrivateField(ctrl, "titleButton", titleBtn);
            SetPrivateField(ctrl, "statsText", statsText);
            SetPrivateField(ctrl, "titleScene", TitleScreen);
            SetPrivateField(ctrl, "transition", fadeBlack);

            SaveScene(scene, GameOver);
        }

        // ===========================================================
        // Scene: Victory
        // ===========================================================

        private static void BuildScene_Victory()
        {
            var scene = NewScene(Victory);

            CreateCamera("Main Camera", new Color(0.06f, 0.10f, 0.16f));

            var canvas = CreateCanvas("VictoryCanvas", 0);

            CreateLabel(canvas.transform, "Title", "VICTORY", TextAnchor.MiddleCenter, 0, 200, 1600, 220, 130, new Color(1f, 0.90f, 0.45f));
            CreateLabel(canvas.transform, "Subtitle", "all three levels cleared", TextAnchor.MiddleCenter, 0, 90, 1600, 60, 30, new Color(0.55f, 0.85f, 1f));

            var line = new GameObject("DivLine");
            line.transform.SetParent(canvas.transform, false);
            var lineImg = line.AddComponent<Image>();
            lineImg.sprite = SquareSprite;
            lineImg.color = new Color(1f, 0.90f, 0.45f, 0.5f);
            lineImg.raycastTarget = false;
            var lineRT = lineImg.rectTransform;
            ApplyAnchor(lineRT, TextAnchor.MiddleCenter);
            lineRT.sizeDelta = new Vector2(420, 2);
            lineRT.anchoredPosition = new Vector2(0, 50);

            var statsText = CreateLabel(canvas.transform, "StatsText", "",
                TextAnchor.MiddleCenter, 0, -30, 1200, 120, 30, new Color(1f, 1f, 1f, 0.9f));

            var titleBtn = CreateThemedButton(canvas.transform, "TitleButton", "RETURN TO TITLE", 0, -210, 540, 90, new Color(1f, 0.90f, 0.45f));

            var ctrlGO = new GameObject("VictoryController");
            var ctrl = ctrlGO.AddComponent<VictoryController>();
            SetPrivateField(ctrl, "titleButton", titleBtn);
            SetPrivateField(ctrl, "statsText", statsText);
            SetPrivateField(ctrl, "titleScene", TitleScreen);
            SetPrivateField(ctrl, "transition", fadeWhite);

            SaveScene(scene, Victory);
        }

        // ===========================================================
        // Visual factories
        // ===========================================================

        private static void CreateBorderQuad(string name, Vector3 pos, Vector2 size, Color color)
        {
            var go = new GameObject(name);
            go.transform.position = pos;
            go.transform.localScale = new Vector3(size.x, size.y, 1f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = SquareSprite;
            sr.color = color;
            sr.sortingOrder = 5;
        }

        private static void CreateBackgroundGradient(Color top, Color bottom)
        {
            var bg = new GameObject("Background");
            bg.transform.position = new Vector3(0, 0, 5f);
            bg.transform.localScale = new Vector3(50f, 30f, 1f);
            var sr = bg.AddComponent<SpriteRenderer>();
            sr.sprite = SquareSprite;
            sr.color = bottom;
            sr.sortingOrder = -100;

            // Subtle vertical gradient — no ambient particles, no animation
            var topHalf = new GameObject("BackgroundTop");
            topHalf.transform.position = new Vector3(0, 7.5f, 4f);
            topHalf.transform.localScale = new Vector3(50f, 15f, 1f);
            var topSR = topHalf.AddComponent<SpriteRenderer>();
            topSR.sprite = SquareSprite;
            topSR.color = new Color(top.r, top.g, top.b, 0.7f);
            topSR.sortingOrder = -99;
        }

        // ===========================================================
        // UI factory helpers
        // ===========================================================

        private static GameObject CreateCamera(string name, Color background)
        {
            var go = new GameObject(name);
            var cam = go.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = background;
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            go.tag = "MainCamera";
            go.transform.position = new Vector3(0, 0, -10);
            return go;
        }

        private static GameObject CreateCanvas(string name, int sortingOrder)
        {
            var go = new GameObject(name);
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = sortingOrder;
            var scaler = go.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            go.AddComponent<GraphicRaycaster>();
            return go;
        }

        private static GameObject CreatePanel(Transform parent, string name, Color color)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>();
            img.color = color;
            return go;
        }

        private static TextMeshProUGUI CreateLabel(
            Transform parent, string name, string text,
            TextAnchor anchor, float x, float y, float w, float h,
            float fontSize = 28, Color? color = null)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = fontSize;
            tmp.color = color ?? Color.white;
            tmp.alignment = ToTMPAlignment(anchor);
            tmp.raycastTarget = false;
            tmp.richText = true;

            var rt = tmp.rectTransform;
            ApplyAnchor(rt, anchor);
            rt.sizeDelta = new Vector2(w, h);
            rt.anchoredPosition = new Vector2(x, y);
            return tmp;
        }

        private static Button CreateThemedButton(Transform parent, string name, string label, float x, float y, float w, float h, Color tint)
        {
            // Darker outer frame (4px wider on each side) — gives the button a clean border
            var frame = new GameObject(name + "_Frame");
            frame.transform.SetParent(parent, false);
            var frameImg = frame.AddComponent<Image>();
            frameImg.sprite = SquareSprite;
            frameImg.color = Color.Lerp(tint, Color.black, 0.55f);
            frameImg.raycastTarget = false;
            var frameRT = frameImg.rectTransform;
            ApplyAnchor(frameRT, TextAnchor.MiddleCenter);
            frameRT.sizeDelta = new Vector2(w + 8, h + 8);
            frameRT.anchoredPosition = new Vector2(x, y);

            // Inner button face
            var go = new GameObject(name);
            go.transform.SetParent(frame.transform, false);
            var img = go.AddComponent<Image>();
            img.sprite = SquareSprite;
            img.color = tint;
            var btn = go.AddComponent<Button>();
            var rt = img.rectTransform;
            ApplyAnchor(rt, TextAnchor.MiddleCenter);
            rt.sizeDelta = new Vector2(w, h);
            rt.anchoredPosition = Vector2.zero;

            var colors = btn.colors;
            colors.normalColor = new Color(1f, 1f, 1f);
            colors.highlightedColor = new Color(1.18f, 1.18f, 1.18f);
            colors.pressedColor = new Color(0.78f, 0.78f, 0.78f);
            colors.disabledColor = new Color(0.4f, 0.4f, 0.4f, 0.5f);
            btn.colors = colors;

            var text = CreateLabel(go.transform, "Text", label, TextAnchor.MiddleCenter, 0, 0, w, h, 32, new Color(0.06f, 0.07f, 0.12f));
            text.fontStyle = FontStyles.Bold;

            return btn;
        }

        // ===========================================================
        // Anchor / alignment helpers
        // ===========================================================

        private static void StretchFull(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static void ApplyAnchor(RectTransform rt, TextAnchor anchor)
        {
            Vector2 a = new Vector2(0.5f, 0.5f);
            Vector2 p = new Vector2(0.5f, 0.5f);
            switch (anchor)
            {
                case TextAnchor.UpperLeft:    a = new Vector2(0, 1); p = new Vector2(0, 1); break;
                case TextAnchor.UpperCenter:  a = new Vector2(0.5f, 1); p = new Vector2(0.5f, 1); break;
                case TextAnchor.UpperRight:   a = new Vector2(1, 1); p = new Vector2(1, 1); break;
                case TextAnchor.MiddleLeft:   a = new Vector2(0, 0.5f); p = new Vector2(0, 0.5f); break;
                case TextAnchor.MiddleCenter: a = new Vector2(0.5f, 0.5f); p = new Vector2(0.5f, 0.5f); break;
                case TextAnchor.MiddleRight:  a = new Vector2(1, 0.5f); p = new Vector2(1, 0.5f); break;
                case TextAnchor.LowerLeft:    a = new Vector2(0, 0); p = new Vector2(0, 0); break;
                case TextAnchor.LowerCenter:  a = new Vector2(0.5f, 0); p = new Vector2(0.5f, 0); break;
                case TextAnchor.LowerRight:   a = new Vector2(1, 0); p = new Vector2(1, 0); break;
            }
            rt.anchorMin = a;
            rt.anchorMax = a;
            rt.pivot = p;
        }

        private static TextAlignmentOptions ToTMPAlignment(TextAnchor anchor)
        {
            switch (anchor)
            {
                case TextAnchor.UpperLeft:    return TextAlignmentOptions.TopLeft;
                case TextAnchor.UpperCenter:  return TextAlignmentOptions.Top;
                case TextAnchor.UpperRight:   return TextAlignmentOptions.TopRight;
                case TextAnchor.MiddleLeft:   return TextAlignmentOptions.Left;
                case TextAnchor.MiddleCenter: return TextAlignmentOptions.Center;
                case TextAnchor.MiddleRight:  return TextAlignmentOptions.Right;
                case TextAnchor.LowerLeft:    return TextAlignmentOptions.BottomLeft;
                case TextAnchor.LowerCenter:  return TextAlignmentOptions.Bottom;
                case TextAnchor.LowerRight:   return TextAlignmentOptions.BottomRight;
            }
            return TextAlignmentOptions.Center;
        }

        // ===========================================================
        // Scene file helpers
        // ===========================================================

        private static Scene NewScene(string name)
        {
            return EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        }

        private static void SaveScene(Scene scene, string name)
        {
            var path = ScenesDir + "/" + name + ".unity";
            EditorSceneManager.SaveScene(scene, path);
        }

        private static void AddToBuildSettings()
        {
            var ordered = new[] {
                Persistent, TitleScreen,
                Level_Garden, Level_Cyber, Level_Void,
                PauseMenu, StatsOverlay, SettingsOverlay,
                GameOver, Victory
            };
            var list = new List<EditorBuildSettingsScene>();
            foreach (var name in ordered)
            {
                var p = ScenesDir + "/" + name + ".unity";
                list.Add(new EditorBuildSettingsScene(p, true));
            }
            EditorBuildSettings.scenes = list.ToArray();
        }

        // ===========================================================
        // Reflection helpers
        // ===========================================================

        private static void SetPrivateField(Object target, string fieldName, object value)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(fieldName);
            if (prop == null)
            {
                Debug.LogError($"[SceneManagerDemoGenerator] Field '{fieldName}' not found on {target.GetType().Name}");
                return;
            }

            switch (prop.propertyType)
            {
                case SerializedPropertyType.String: prop.stringValue = (string)value; break;
                case SerializedPropertyType.Integer: prop.intValue = (int)value; break;
                case SerializedPropertyType.Float: prop.floatValue = (float)value; break;
                case SerializedPropertyType.Boolean: prop.boolValue = (bool)value; break;
                case SerializedPropertyType.Color: prop.colorValue = (Color)value; break;
                case SerializedPropertyType.ObjectReference: prop.objectReferenceValue = (Object)value; break;
                case SerializedPropertyType.Vector2: prop.vector2Value = (Vector2)value; break;
                case SerializedPropertyType.Vector3: prop.vector3Value = (Vector3)value; break;
                case SerializedPropertyType.Vector2Int: prop.vector2IntValue = (Vector2Int)value; break;
                default:
                    Debug.LogError($"[SceneManagerDemoGenerator] Unsupported property type {prop.propertyType} for field '{fieldName}'");
                    break;
            }
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void SetPrivateStringArray(Object target, string fieldName, string[] values)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(fieldName);
            if (prop == null) { Debug.LogError($"Field '{fieldName}' not found on {target.GetType().Name}"); return; }
            prop.arraySize = values.Length;
            for (int i = 0; i < values.Length; i++)
            {
                prop.GetArrayElementAtIndex(i).stringValue = values[i];
            }
            so.ApplyModifiedPropertiesWithoutUndo();
        }
    }
}
